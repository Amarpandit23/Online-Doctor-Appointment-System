import React, { useState, useEffect } from "react";
import Layout from "./../../components/Layout";
import axios from "axios";
import moment from "moment";
import { message, Table, Button, Tag } from "antd";
import "./DoctorAppointments.css"; // Import the CSS file

const DoctorAppointments = () => {
  const [appointments, setAppointments] = useState([]);

  const getAppointments = async () => {
    try {
      const res = await axios.get("/api/v1/doctor/doctor-appointments", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAppointments(res.data.data);
      }
    } catch (error) {
      console.log(error);
      message.error("Failed to fetch appointments");
    }
  };

  useEffect(() => {
    getAppointments();
  }, []);

  const handleStatus = async (record, status) => {
    try {
      const res = await axios.post(
        "/api/v1/doctor/update-status",
        { appointmentsId: record.id, status },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        getAppointments();
      }
    } catch (error) {
      console.log(error);
      message.error("Failed to update status");
    }
  };

  const columns = [
    {
      title: "ID",
      dataIndex: "_id",
      key: "_id",
      width: "10%",
    },
    {
      title: "Date & Time",
      dataIndex: "date",
      key: "date",
      render: (text, record) => (
        <span>
          {moment(record.date).format("DD-MM-YYYY")} &nbsp;
          {moment(record.time).format("HH:mm")}
        </span>
      ),
      width: "25%",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => (
        <Tag
          color={
            status === "pending"
              ? "orange"
              : status === "approved"
              ? "green"
              : "red"
          }
        >
          {status.toUpperCase()}
        </Tag>
      ),
      width: "20%",
    },
    {
      title: "Actions",
      key: "actions",
      render: (text, record) => (
        <div className="actions-container">
          {record.status === "pending" && (
            <>
              <Button
                className="action-btn approved-btn"
                onClick={() => handleStatus(record, "approved")}
              >
                Approve
              </Button>
              <Button
                className="action-btn reject-btn"
                onClick={() => handleStatus(record, "rejected")}
              >
                Reject
              </Button>
            </>
          )}
        </div>
      ),
      width: "25%",
    },
  ];

  return (
    <Layout>
      <div className="appointments-container">
        <h1 className="appointments-title">Appointment Lists</h1>
        <Table
          columns={columns}
          dataSource={appointments}
          rowKey="_id"
          className="appointments-table"
        />
      </div>
    </Layout>
  );
};

export default DoctorAppointments;
