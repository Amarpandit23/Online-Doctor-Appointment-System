const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db");
const User = require("./userModels"); // Import the User model

const Notification = sequelize.define(
  "Notification",
  {
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: User, // Reference to User model
        key: "id",
      },
    },
    type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    message: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    seen: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    onClickPath: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    tableName: "notifications",
    timestamps: true, // Sequelize will automatically add `createdAt` and `updatedAt` fields
  }
);

// Define associations
Notification.belongsTo(User, { foreignKey: "userId" });

module.exports = Notification;
