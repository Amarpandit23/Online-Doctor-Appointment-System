const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/userModels");
const Doctor = require("../models/doctorModel");
const Appointment = require("../models/appointmentModel");
const moment = require("moment");
const Notification = require("../models/notificationModel");
const { Op } = require("sequelize");

const registerController = async (req, res) => {
  try {
    const existingUser = await User.findOne({
      where: { email: req.body.email },
    });
    if (existingUser) {
      return res
        .status(200)
        .send({ message: "User Already Exist", success: false });
    }
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    await User.create({
      ...req.body,
      password: hashedPassword,
    });
    res.status(201).send({ message: "Register Successfully", success: true });
  } catch (error) {
    console.error(error);
    res.status(500).send({
      success: false,
      message: `Register Controller ${error.message}`,
    });
  }
};

// login callback
const loginController = async (req, res) => {
  try {
    const user = await User.findOne({ where: { email: req.body.email } });
    if (!user) {
      return res
        .status(200)
        .send({ message: "User not found", success: false });
    }
    const isMatch = await bcrypt.compare(req.body.password, user.password);
    if (!isMatch) {
      return res
        .status(200)
        .send({ message: "Invalid Email or Password", success: false });
    }
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });
    res.status(200).send({ message: "Login Success", success: true, token });
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: `Error in Login CTRL ${error.message}` });
  }
};

const authController = async (req, res) => {
  try {
    const user = await User.findByPk(req.body.userId);
    if (!user) {
      return res
        .status(200)
        .send({ message: "User not found", success: false });
    }
    user.password = undefined;
    res.status(200).send({ success: true, data: user });
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Auth error", success: false, error });
  }
};
const applyDoctorController = async (req, res) => {
  try {
    const { timings } = req.body;

    // Check if timings are provided and are in the correct format
    if (!Array.isArray(timings) || timings.length !== 2) {
      return res.status(400).send({
        success: false,
        message: "Timings must be an array with two elements",
      });
    }

    // Parse and format timings
    const formattedTimings = timings.map((time) => {
      // Check if time is a valid format
      const parsedTime = moment(time, ["HH:mm", "h:mm A"], true);
      if (!parsedTime.isValid()) {
        throw new Error(`Invalid time format: ${time}`);
      }
      return parsedTime.format("HH:mm");
    });

    // Create a new doctor entry
    const newDoctor = await Doctor.create({
      ...req.body,
      timings: formattedTimings,
      status: "pending",
    });

    // Find the admin user
    const adminUser = await User.findOne({ where: { isAdmin: true } });

    if (!adminUser) {
      return res.status(404).send({
        success: false,
        message: "Admin user not found",
      });
    }

    // Create a new notification
    await Notification.create({
      userId: adminUser.id,
      type: "apply-doctor-request",
      message: `${newDoctor.firstName} ${newDoctor.lastName} has applied for a doctor account`,
      seen: false,
      onClickPath: "/admin/doctors",
    });

    res.status(201).send({
      success: true,
      message: "Doctor account applied successfully",
    });
  } catch (error) {
    console.error("Error in applyDoctorController:", error);
    res.status(500).send({
      success: false,
      message: "Error while applying for doctor",
      error,
    });
  }
};

const getAllNotificationController = async (req, res) => {
  try {
    // Get the user ID from the request body
    const { userId } = req.body;

    // Find the user by ID
    const user = await User.findByPk(userId);
    if (!user) {
      return res
        .status(404)
        .send({ message: "User not found", success: false });
    }

    // Retrieve notifications for the user
    const notifications = await Notification.findAll({
      where: { userId },
      order: [["createdAt", "DESC"]], // Optionally order by most recent
    });

    // Mark all notifications as seen
    await Notification.update(
      { seen: true },
      { where: { userId, seen: false } }
    );

    res.status(200).send({
      success: true,
      message: "All notifications retrieved and marked as read",
      data: notifications,
    });
  } catch (error) {
    console.error("Error retrieving notifications:", error);
    res.status(500).send({
      message: "Error retrieving notifications",
      success: false,
      error: error.message || error,
    });
  }
};

const deleteAllNotificationController = async (req, res) => {
  try {
    // Get the user ID from the request body
    const { userId } = req.body;

    // Find the user by ID
    const user = await User.findByPk(userId);
    if (!user) {
      return res
        .status(404)
        .send({ message: "User not found", success: false });
    }

    // Delete all notifications for the user
    await Notification.destroy({
      where: { userId },
    });

    res.status(200).send({
      success: true,
      message: "All notifications deleted successfully",
    });
  } catch (error) {
    console.error("Error deleting notifications:", error);
    res.status(500).send({
      success: false,
      message: "Unable to delete all notifications",
      error: error.message || error,
    });
  }
};

const getAllDocotrsController = async (req, res) => {
  try {
    const doctors = await Doctor.findAll({ where: { status: "approved" } });
    res.status(200).send({
      success: true,
      message: "Doctors List Fetched Successfully",
      data: doctors,
    });
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .send({ success: false, message: "Error While Fetching Doctors", error });
  }
};

const bookAppointmentController = async (req, res) => {
  try {
    const { doctorId, userId, date, time } = req.body;

    // Validate that the user and doctor exist
    const user = await User.findByPk(userId);
    const doctor = await Doctor.findByPk(doctorId);

    if (!user) {
      return res.status(404).send({
        success: false,
        message: "User not found",
      });
    }

    if (!doctor) {
      return res.status(404).send({
        success: false,
        message: "Doctor not found",
      });
    }

    // Create the new appointment
    const newAppointment = await Appointment.create({
      userId,
      doctorId,
      date: moment(date, "DD-MM-YYYY").toDate(),
      time: moment(time, "HH:mm").toDate(),
      status: "pending",
    });

    // Create a notification for the doctor
    await Notification.create({
      userId: doctor.userId,
      type: "New-appointment-request",
      message: `A new appointment request from ${user.name}`,
      onClickPath: "/doctor/appointments",
    });

    res.status(200).send({
      success: true,
      message: "Appointment Booked Successfully",
    });
  } catch (error) {
    console.error("Error while booking appointment:", error);
    res.status(500).send({
      success: false,
      message: "Error While Booking Appointment",
      error: error.message || error,
    });
  }
};

const bookingAvailabilityController = async (req, res) => {
  try {
    const date = moment(req.body.date, "DD-MM-YYYY").toDate();
    const fromTime = moment(req.body.time, "HH:mm")
      .subtract(1, "hours")
      .toDate();
    const toTime = moment(req.body.time, "HH:mm").add(1, "hours").toDate();
    const doctorId = req.body.doctorId;
    const appointments = await Appointment.findAll({
      where: {
        doctorId,
        date,
        time: {
          [Op.between]: [fromTime, toTime],
        },
      },
    });
    if (appointments.length > 0) {
      return res.status(200).send({
        message: "Appointments not available at this time",
        success: true,
      });
    } else {
      return res
        .status(200)
        .send({ success: true, message: "Appointments available" });
    }
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .send({ success: false, message: "Error In Booking", error });
  }
};

const userAppointmentsController = async (req, res) => {
  try {
    const { userId } = req.body;

    // Fetch user details
    const user = await User.findByPk(userId, {
      attributes: ["id", "name", "email", "createdAt"], // Include fullName and email in the attributes
    });

    if (!user) {
      return res.status(404).send({
        success: false,
        message: "User not found",
      });
    }

    // Fetch appointments for the user
    const appointments = await Appointment.findAll({
      where: { userId },
      attributes: ["id", "date", "time", "status", "doctorId"], // Include doctorId in the attributes
    });

    // Fetch doctor details for each appointment
    const appointmentsWithDoctorAndUserInfo = await Promise.all(
      appointments.map(async (appointment) => {
        const doctor = await Doctor.findByPk(appointment.doctorId); // Fetch doctor details
        return {
          ...appointment.toJSON(), // Convert appointment to plain object
          user: {
            name: user.name,
            email: user.email,
            id: user.id,
            createdAt: user.createdAt,
          },
          doctor: doctor
            ? {
                firstName: doctor.firstName,
                lastName: doctor.lastName,
                phone: doctor.phone,
                specialization: doctor.specialization,
                fees: doctor.feesPerConsultation,
              }
            : null,
        };
      })
    );

    res.status(200).send({
      success: true,
      message: "User's Appointments Fetched Successfully",
      data: appointmentsWithDoctorAndUserInfo,
    });
  } catch (error) {
    console.error(error);
    res.status(500).send({
      success: false,
      message: "Error In User Appointments",
      error: error.message || error,
    });
  }
};

module.exports = {
  loginController,
  registerController,
  authController,
  applyDoctorController,
  getAllNotificationController,
  deleteAllNotificationController,
  getAllDocotrsController,
  bookAppointmentController,
  bookingAvailabilityController,
  userAppointmentsController,
};
