const appointmentModel = require("../models/appointmentModel");
const doctorModel = require("../models/doctorModel");
const userModel = require("../models/userModels");
const Notification = require("../models/notificationModel");

const getDoctorInfoController = async (req, res) => {
  try {
    const doctor = await doctorModel.findOne({
      where: { userId: req.body.userId },
    });
    res.status(200).send({
      success: true,
      message: "Doctor data fetch success",
      data: doctor,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      error,
      message: "Error in Fetching Doctor Details",
    });
  }
};

const updateProfileController = async (req, res) => {
  try {
    const doctor = await doctorModel.findOne({
      where: { userId: req.body.userId },
    });
    if (!doctor) {
      return res.status(404).send({
        success: false,
        message: "Doctor not found",
      });
    }
    const updatedDoctor = await doctor.update(req.body);
    res.status(200).send({
      success: true,
      message: "Doctor Profile Updated",
      data: updatedDoctor,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Doctor Profile Update issue",
      error,
    });
  }
};

//get single docotor
const getDoctorByIdController = async (req, res) => {
  try {
    const doctor = await doctorModel.findOne({
      where: { id: req.body.doctorId },
    });
    res.status(200).send({
      success: true,
      message: "Single Doctor Info Fetched",
      data: doctor,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      error,
      message: "Error in Single Doctor Info",
    });
  }
};

const doctorAppointmentsController = async (req, res) => {
  try {
    const doctor = await doctorModel.findOne({
      where: { userId: req.body.userId },
    });
    if (!doctor) {
      return res.status(404).send({
        success: false,
        message: "Doctor not found",
      });
    }
    const appointments = await appointmentModel.findAll({
      where: { doctorId: doctor.id },
    });
    res.status(200).send({
      success: true,
      message: "Doctor Appointments fetched Successfully",
      data: appointments,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      error,
      message: "Error in Doctor Appointments",
    });
  }
};

const updateStatusController = async (req, res) => {
  try {
    const { appointmentId, status } = req.body; // Ensure 'appointmentId' matches the request payload

    // Find the appointment by its ID
    const appointment = await appointmentModel.findOne({
      where: { id: appointmentId },
    });

    if (!appointment) {
      return res.status(404).send({
        success: false,
        message: "Appointment not found",
      });
    }

    // Update appointment status
    await appointment.update({ status });

    // Find the associated user
    const user = await userModel.findOne({ where: { id: appointment.userId } });

    if (user) {
      // Create a new notification
      await Notification.create({
        userId: user.id, // assuming `userId` field in Notification model refers to the User
        type: "status-updated",
        message: `Your appointment has been updated to ${status}`,
        onClickPath: "/doctor-appointments",
      });
    }

    res.status(200).send({
      success: true,
      message: "Appointment Status Updated",
    });
  } catch (error) {
    console.error("Error updating appointment status:", error);
    res.status(500).send({
      success: false,
      message: "Error In Update Status",
      error: error.message || error,
    });
  }
};

module.exports = {
  getDoctorInfoController,
  updateProfileController,
  getDoctorByIdController,
  doctorAppointmentsController,
  updateStatusController,
};
