import React, { useEffect, useState } from "react";
import Layout from "./../components/Layout";
import { message, Tabs, Spin, Button } from "antd";
import { useSelector, useDispatch } from "react-redux";
import { showLoading, hideLoading } from "../redux/features/alertSlice";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./NotificationPage.css"; // Import your custom styles

const NotificationPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.user);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(false);

  // Fetch notifications when component mounts
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        setLoading(true);
        const res = await axios.post(
          "/api/v1/user/get-all-notification",
          { userId: user.id },
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );
        setLoading(false);
        if (res.data.success) {
          setNotifications(res.data.data);
        } else {
          message.error(res.data.message);
        }
      } catch (error) {
        setLoading(false);
        console.log(error);
        message.error("Something went wrong while fetching notifications");
      }
    };

    fetchNotifications();
  }, [user]);

  // Handle mark all notifications as read
  const handleMarkAllRead = async () => {
    try {
      dispatch(showLoading());
      const res = await axios.post(
        "/api/v1/notification/mark-all-read",
        { userId: user.id },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      dispatch(hideLoading());
      if (res.data.success) {
        message.success(res.data.message);
        setNotifications(
          notifications.map((notification) => ({
            ...notification,
            isRead: true,
          }))
        );
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      dispatch(hideLoading());
      console.log(error);
      message.error("Something went wrong");
    }
  };

  // Handle delete all notifications
  const handleDeleteAll = async () => {
    try {
      dispatch(showLoading());
      const res = await axios.post(
        "/api/v1/notification/delete-all",
        { userId: user.id },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      dispatch(hideLoading());
      if (res.data.success) {
        message.success(res.data.message);
        setNotifications([]);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      dispatch(hideLoading());
      console.log(error);
      message.error("Something went wrong");
    }
  };

  return (
    <Layout>
      <h4 className="p-3 text-center">Notification Page</h4>
      <Spin spinning={loading} tip="Loading notifications...">
        <Tabs defaultActiveKey="unread">
          <Tabs.TabPane tab="Unread" key="unread">
            <div className="notification-actions">
              <Button
                type="primary"
                onClick={handleMarkAllRead}
                className="action-button"
              >
                Mark All Read
              </Button>
            </div>
            <div className="notification-list">
              {notifications
                .filter((notification) => !notification.isRead)
                .map((notification) => (
                  <div
                    className="notification-card"
                    style={{ cursor: "pointer" }}
                    key={notification.id}
                    onClick={() => navigate(notification.onClickPath)}
                  >
                    <div className="notification-message">
                      {notification.message}
                    </div>
                  </div>
                ))}
              {notifications.length === 0 && <p>No unread notifications.</p>}
            </div>
          </Tabs.TabPane>
          <Tabs.TabPane tab="Read" key="read">
            <div className="notification-actions">
              <Button
                type="danger"
                onClick={handleDeleteAll}
                className="action-button"
              >
                Delete All Read
              </Button>
            </div>
            <div className="notification-list">
              {notifications
                .filter((notification) => notification.isRead)
                .map((notification) => (
                  <div
                    className="notification-card"
                    style={{ cursor: "pointer" }}
                    key={notification.id}
                    onClick={() => navigate(notification.onClickPath)}
                  >
                    <div className="notification-message">
                      {notification.message}
                    </div>
                  </div>
                ))}
              {notifications.length === 0 && <p>No read notifications.</p>}
            </div>
          </Tabs.TabPane>
        </Tabs>
      </Spin>
    </Layout>
  );
};

export default NotificationPage;
