const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db");
const Doctor = require("./doctorModel");
const User = require("./userModels");

const Appointment = sequelize.define(
  "Appointment",
  {
    userId: {
      type: DataTypes.INTEGER, // Assuming primary key is INTEGER
      allowNull: false,
      references: {
        model: User, // Reference to User model
        key: "id",
      },
    },
    doctorId: {
      type: DataTypes.INTEGER, // Assuming primary key is INTEGER
      allowNull: false,
      references: {
        model: Doctor, // Reference to Doctor model
        key: "id",
      },
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("pending", "confirmed", "canceled"),
      defaultValue: "pending",
    },
    time: {
      type: DataTypes.TIME,
      allowNull: false,
    },
  },
  {
    tableName: "appointments",
    timestamps: true,
  }
);

// Define associations
Appointment.belongsTo(User, { foreignKey: "userId", as: "user" });
Appointment.belongsTo(Doctor, { foreignKey: "doctorId", as: "doctor" });

module.exports = Appointment;
