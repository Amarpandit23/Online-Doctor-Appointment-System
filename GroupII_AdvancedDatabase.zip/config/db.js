const { Sequelize } = require("sequelize");
require("dotenv").config();

const sequelize = new Sequelize({
  host: process.env.MYSQL_HOST || "localhost",
  username: process.env.MYSQL_USER || "root",
  password: process.env.MYSQL_PASSWORD || "",
  database: process.env.MYSQL_DATABASE || "testdb",
  dialect: "mysql",
  logging: false, // Set to `true` if you want to see SQL queries in the console
});

const connectDB = async () => {
  try {
    await sequelize.authenticate();
    console.log("Connection to MySQL has been established successfully.");

    // Synchronize all models with the database

    // IMPORTANT NOTE: IF YOU USE PRELOADED DATABASE MIGRATION SRIPTS OR INSERTION WITHOUT SEQUELIZE, PLEASE COMMENT THE FOLLOWING LINE OUT THAT SYNCS THE DATABASE
    await sequelize.sync({ alter: true }); // Use { force: true } if you want to drop and recreate tables, use cautiously
    console.log("Database synchronized successfully.");
  } catch (error) {
    console.error("Unable to connect to the database:", error);
  }
};

// Export both sequelize and connectDB
module.exports = {
  sequelize,
  connectDB,
};
