import React, { useState, useEffect } from "react";
import axios from "axios";
import Layout from "./../components/Layout";
import moment from "moment";
import { Table, Button } from "antd";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import Logo from "../components/logo.png";

// Set pdfMake fonts
pdfMake.vfs = pdfFonts.pdfMake.vfs;

const Appointments = () => {
  const [appointments, setAppointments] = useState([]);

  // Fetch appointments from the API
  const getAppointments = async () => {
    try {
      const res = await axios.get("/api/v1/user/user-appointments", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAppointments(res.data.data);
      } else {
        console.error(res.data.message);
      }
    } catch (error) {
      console.log("Error fetching appointments:", error);
    }
  };

  useEffect(() => {
    getAppointments();
  }, []);

  // Define columns for the table
  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
      // Optional: add alignment or styling
      align: "center",
      render: (text) => <span>{text}</span>,
    },
    {
      title: "Doctor",
      key: "doctor",
      render: (text, record) => (
        <span>
          Dr. {record.doctor.firstName} {record.doctor.lastName}
        </span>
      ),
    },
    {
      title: "Specialization",
      key: "specialization",
      render: (text, record) => <span>{record.doctor.specialization}</span>,
    },
    {
      title: "Date & Time",
      dataIndex: "date",
      key: "date",
      render: (text, record) => (
        <span>
          {moment(record.date).format("DD-MM-YYYY")} &nbsp;
          {moment(record.time, "HH:mm:ss").format("HH:mm")}
        </span>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      align: "center",
      // Optional: add conditional styling based on status
      render: (status) => (
        <span style={{ color: status === "Completed" ? "green" : "red" }}>
          {status}
        </span>
      ),
    },
    {
      title: "Price",
      key: "price",
      align: "right",
      render: (text, record) => (
        <span>${parseFloat(record.doctor.fees).toFixed(2)}</span>
      ),
    },
  ];

  const generatePDF = () => {
    const { name, email, id, createdAt } = appointments[0]?.user || {}; // Assuming the user info is available in the appointments

    // Ensure fees are converted to numbers and calculate subtotal, tax, and grand total
    const subtotal = appointments.reduce(
      (acc, appointment) => acc + parseFloat(appointment.doctor.fees) || 0,
      0
    );
    const tax = subtotal * 0.13; // 13% tax
    const grandTotal = subtotal + tax;

    // Format numbers to two decimal places
    const formatCurrency = (amount) => `$${amount.toFixed(2)}`;

    // Helper function to create table rows with pagination
    const createTableBody = (appointments) => {
      const rowsPerPage = 10; // Number of rows per page
      let pages = [];
      let currentPage = [];

      // Header for each page
      const header = [
        { text: "ID", style: "tableHeader" },
        { text: "Doctor", style: "tableHeader" },
        { text: "Specialization", style: "tableHeader" },
        { text: "Date & Time", style: "tableHeader" },
        { text: "Status", style: "tableHeader" },
        { text: "Price", style: "tableHeader" },
      ];

      for (let i = 0; i < appointments.length; i++) {
        if (i > 0 && i % rowsPerPage === 0) {
          pages.push(currentPage);
          currentPage = [];
        }
        currentPage.push([
          appointments[i].id,
          `Dr. ${appointments[i].doctor.firstName} ${appointments[i].doctor.lastName}`,
          appointments[i].doctor.specialization,
          `${moment(appointments[i].date).format("DD-MM-YYYY")} ${moment(
            appointments[i].time,
            "HH:mm:ss"
          ).format("HH:mm")}`,
          appointments[i].status,
          formatCurrency(parseFloat(appointments[i].doctor.fees) || 0),
        ]);
      }
      if (currentPage.length > 0) {
        pages.push(currentPage);
      }

      return pages.map((body, index) => ({
        table: {
          headerRows: 1,
          widths: [40, "*", "*", "*", "*", "*"],
          body: [header, ...body],
        },
        layout: {
          fillColor: (rowIndex) => (rowIndex % 2 === 0 ? "#f9f9f9" : null), // Alternate row colors
          hLineColor: () => "#ddd", // Light grey horizontal lines
          vLineColor: () => "#ddd", // Light grey vertical lines
          hLineWidth: () => 1, // Horizontal line thickness
          vLineWidth: () => 1, // Vertical line thickness
          paddingLeft: () => 5,
          paddingRight: () => 5,
          paddingTop: () => 5,
          paddingBottom: () => 5,
        },
        margin: [0, 10, 0, 10],
        pageBreak: index < pages.length - 1 ? "after" : null, // Add page break except on the last page
      }));
    };

    const docDefinition = {
      content: [
        {
          columns: [
            {
              width: "70%",
              text: "Online Doctor Appointment System",
              style: "title",
              alignment: "left",
              color: "#000080", // Dark red color for title
            },
            {
              width: "30%",
              image:
                "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeF7tnQe0LEW1hr8CRFABSZJEJIj6BJ5IFAQRzCTJgqBy4RFUlCRZQZ9cgiQVSRJUQJKiREUFCZJBfICCSBCQDJIkiEK/9U/P0cO5Z7p7Zrp7Ovx7rbMOeruran81Z/rvql17B2wmYAIVJxDNAMwFzN39PScwBzA78EZgNmBWYBbgDcDrgdcBMwMzAa8FZuxel8XXp4GXgH8ALwIvAM8DzwF/B54FngF03VPAk8DfgCeAx4HH4t/hX1k68zUmYAKjIRBG0617NQETiAlEenAvBLyl+3sBYP7uz3yAfvTAr9vfatQVBA8B+nmw+/MAcC9wX/w7SEjYTMAERkCgbl8qI0DkLk1gWALRPMDiwNuAxbo/iwBv7T7ch+2gzvdr1eCe7s+dgH7+DNwB4ZE6O+axm0DVCVgAVH2GPL4aEYj09r4E8F/d3+8E3tFdqq+RH5UZqrYWbgduA24F/hD/BK0i2EzABIYkYAEwJEDf3kYC0fTdB/t7gKWB/wb039qPtxVPQHEHvwP+D7ip+9+3Q3i5+K7dgwk0h4AFQHPm0p4URiDScv17gWWB5YB3dwPtCuvRDfdNQAGKvweuB24AroZwd9+t+AYTaBEBC4AWTbZdzUIgUsT8MsDKwErAKt6nz8KtktcovuC3wJXdnxsh6GSDzQRMoIaRxZ40E8iZQKSjcisAqwHvB5bvHqHLuR83VwECOsp4HXBZ9+caCDriaDOBVhLwCkArp73NTkfTdZfyPwis0V3alwiwtY+AHv5XAxcDv463DsIr7cNgj9tKwAKgrTPfKr870fkfBj4G6MGvBDo2E5hIQKcOJAR+DvzSpw38AWk6AQuAps9wK/2L9LleEVir+9BXpL7NBPoloBMGEgPnA9ouUHIjmwk0hoAFQGOmsu2OdPby9Xa/HvBxQMl3bCaQFwElJboQ+Gm8SuDYgbzAup3REbAAGB179zw0gUi577WsvxHwkW4u/KFbdQMmkEJAtRAuAs6KVwiC/rfNBGpHwAKgdlPW9gFHKnajN/xPdh/6KnpjM4FREdDJAomB0+MVgqBiSTYTqAUBC4BaTFPbBxmpkp2C+D7V3deXCLCZQNUI6OGveIFTu0GEqqhoM4HKErAAqOzUeGAQ6Xz+FsAm3TK4hmICdSGgsshnACdDuLYug/Y420XAAqBd810DbyOVv/0M8GlAxXRsJlB3Aipm9EPgBxBUGtlmApUgYAFQiWlo+yCiGYA1gf8BPgqo2I7NBJpGQMWKfgF8D7gAwr+a5qD9qRcBC4B6zVfDRhu9tfvQnwLM2zDn7I4JJBF4GDgxFgPhL0ZlAqMgYAEwCuqt7zPS0b0vdKP5W0/DAFpPQPkFjoSgpEM2EyiNgAVAaajb3lGk9Lt60/8coPK6NhMwgVcTuAs4Ol4ZCEpLbDOBQglYABSK141D9HZgZ2BTJ+rx58EEMhFQYqHTgMMg/CnTHb7IBAYgYAEwADTfkoVApPK6u3TP7We5wdeYgAlMS0B5BQ6FcKnhmEDeBCwA8iba6vY6RXg2AHYDlms1CjtvAvkSuB44CDjbRYnyBdvm1iwA2jz7ufkezdQ9u78rsFhuzbohEzCBiQTuBA7p5hR40XhMYBgCFgDD0Gv9vZ28/Nt0l/rnbz0OAzCB8gg8GG8NcJzrD5QHvWk9WQA0bUZL8SeaFdi+G9z3plK6dCcmYAKTEXg0DhbU6YHwjBGZQD8ELAD6odX6azvld3WMT1H9fvC3/vNgABUiMCYEjnJ54grNSsWHYgFQ8QmqxvCimbtv/Arum6caY/IoTMAEJiHwCHBwd0XgBRMygSQCFgD+fCQQ6OTo3xrYB1jAqEzABGpD4AHgG8DxrjlQmzkrfaAWAKUjr0uH0frAAcDidRmxx2kCJjANgTuAPSGcbTYmMJGABYA/ExMIRKt2lxBXMBoTMIHGELgO+DKEyxvjkR0ZmoAFwNAIm9JApPP7Ola0TlM8sh8mYALTEDg3PrYblE/A1nICFgAt/wBANCewV7c634ytx2EAJtB8Ai/F1QeZCuGJ5rtrD3sRsABo7Wcjmq57pO+rwNytxWDHTaC9BB4Dvg7o6OAr7cXQXs8tAFo599Eq3TeApVrpvp02ARMYT+DmeAUwXGEs7SJgAdCq+Y6UrlcFRTZvldt21gRMIAuBU4DdISjNsK0FBCwAWjDJ0Fnu/xLwFWD2VrhsJ03ABAYh8CTwv8C3vC0wCL563WMBUK/5GmC0kcryHgssPcDNvsUETKCdBG4CtoWgMsS2hhKwAGjoxEI0G7AfsGNjXbRjJmACRRM4Iv4eCU8X3ZHbL5+ABUD5zEvoMVozzgXOgiV05i5MwASaTeD+uBZIuKDZbrbPOwuARs15pAp9UuybNsotO2MCJlAFAqfFK4pBlQdtDSBgAdCASYxdiPTQP9zV+hozoXbEBKpIQNUGd4IgMWCrOQELgJpPIEQqz/sdYKPau2IHTMAE6kLgLGAHCBIEtpoSsACo6cR13/o37D785621Gx68CZhAHQk83BUBP67j4D1msACo5acg0ln+bwJb1XL4HrQJmECTCJzQrTSoHAK2GhGwAKjRZHXf+pXG92RgodoN3QM2ARNoKoF7gS2cTrhe02sBUJv5il7TPdevyn02EzABE6gigandvAH/rOLgPKZXE7AAqMUnIloEOBNYphbD9SBNwATaTOBGYGMId7cZQh18twCo/CxFWwKHAW+s/FA9QBMwAROICTzVPS74fQOpLgELgMrOTTRLN9Bv28oO0QMzARMwgWQCqkPyZQjPGlT1CFgAVG9OlNRnceA8QL9tJmACJlBnAncAa0PQb1uFCFgAVGgy4qFEU7rpfLUCYDMBEzCBJhDQCoDSCJ/YBGea4oMFQGVmMpoJODhOrGEzARMwgUYSUNbS3SC82EjvauaUBUAlJix6C/BT4D2VGI4HYQImYALFEdApgfUh3FdcF245CwELgCyUCr0mWhU4A3A630I5u3ETMIEKEVAa4U0gXF6hMbVuKBYAI53yaJdupL/nYaTz4M5NwARGQCDqnhA4dAR9u0tcC2BEH4Jo5m6g3zYjGoC7NQETMIGqEDiuGyD4QlUG1JZx+M2z9JmO5gfOAZYtvWt3aAImYALVJHADsC6EB6s5vGaOygKg1HmNlgAuBBYstVt3ZgImYALVJ3A/8HEIt1Z/qM0YoQVAafMYfRI4Hnh9aV26IxMwAROoF4HngK0hnF6vYddztBYApcxbtDtwYClduRMTMAETqD+BPSAcVH83qu2BBUCh8xNN1w32c3KfQjm7cRMwgQYSUNKgnSC83EDfKuGSBUBh0xDNCvwIWLOwLtywCZiACTSbwAXApyA83Ww3R+OdBUAh3KP5gIuAJQtp3o2agAmYQHsI3AJ8BMJD7XG5HE8tAHLnHC0K/ApYOPem3aAJmIAJtJPAPcCHINzVTveL8doCIFeu0VLdN3+n9c2VqxszARMwAZQ+WCsBN5tFPgQsAPLhqDK+awA/AWbLrUk3ZAImYAImMJ6AYgE2gHCxsQxPwAJgeIZ6+OuM/0mASvraTMAETMAEiiOgUsJbOlfA8IAtAIZmGG0HHOW6CkODdAMmYAImkJWACgl9DsIxWW/wddMSsAAY6lMR7Qy4ktVQDH2zCZiACQxMYBcIhw18d8tvtAAY+AMQ7QXsP/DtvtEETMAETCAPAntDmJpHQ21rwwJgoBmP9gP2HehW32QCJmACJpA3ga9B0PeyrQ8CFgB9wIovjb4B7N33bb7BBEzABEygSAL7Q9inyA6a1rYFQF8zGmmZac++bvHFJmACJmACZRE4AIK2Z20ZCFgAZIDUffP3wz8zK19oAiZgAiMjYBGQEb0FQCZQXvbPhMkXmYAJmEA1CHg7IMM8WACkQnLAXyoiX2ACJmAC1SPgwMCUObEASATko37V+5v2iEzABEwgMwEfEUxAZQHQE46T/GT+E/OFJmACJlBdAk4W1GNuLAAmBdNJ73t0dT/PHpkJmIAJmEAfBLZ32uBpaVkATMOkU9jnR87t38efli81ARMwgWoTUO2AzVxA6NWTZAHwKh6dkr7nu6pftf+SPToTMAETGICAqgiu5VLC/yFnAfBvFtFSwOXAbAN8sHyLCZiACZhA9Qk8DawK4ebqD7X4EVoAdBhHiwK/BeYtHrl7MAETMAETGCGBh4H3QbhrhGOoRNcWAETzAVcCC1diRjwIEzABEzCBogncA6wM4aGiO6py+y0XAJGW+68AlqzyJHlsJmACJmACuRO4pbsS8EzuLdekwRYLgGh64BxgzZrMlYdpAiZgAiaQL4ELgHUgvJJvs/Vorc0C4NvADvWYJo/SBEzABEygIALfgfDFgtqudLMtFQDR7sCBlZ4ZD84ETMAETKAsAntAOKiszqrSTwsFQCfRz2lVmQCPwwRMwARMoBIENm1boqCWCYBoCeAa4PWV+Lh5ECZgAiZgAlUh8BywIoRbqzKgosfRIgEQzd99+C9YNFS3bwImYAImUEsC93dFwIO1HH2fg26JAIhm7mb5W7ZPPr7cBEzABEygXQRu6GYLfKHpbrdFABwLbNP0ybR/JmACJmACuRA4DsK2ubRU4UZaIACiXYBDKjwHHpoJmIAJmED1COwK4dDqDSu/ETVcAESrApe6tG9+Hxi3ZAImYAItIaASwqtBUJG4RlqDBUD0FuBaF/hp5OfWTpmACZhAGQRUOGgFCPeV0VnZfTRUAEQzdav7LVM2UPdnAiZgAibQKAK/6xYOerFRXjV3aTxymt+mfVLtjwmYgAmMjkAj0wU3cAUgmgKcMLrPiXs2ARMwARNoIIGtIJzYJL8aJgCixQGd4ZylSZNkX0zABEzABEZO4FlgWQh3jHwkOQ2gQQIg0kNfD3+JAJsJmIAJmIAJ5E1AD3+JAImB2luTBMAxQOMTN9T+E2cHTMAETKDeBI6FsF29XYhH3xABEH0WOKkJE2IfTMAETMAEKk9gCoTaP3MaIACiRYAbgTdW/iPjAZqACZiACTSBwFPAMhDurrMzNRcA0WuAq+OJsJmACZiACZhAaQT04vleCP8srcecO6q7ANgf2CtnJm7OBEzABEzABLIQmAph7ywXVvGaGguAaJVuid8qcvWYTMAETMAE2kFgVQhX1NHVmgqAaHbgJmChOkL3mE3ABEzABBpD4F5gaQhP1s2jugqA44Gt6gbb4zUBEzABE2gkgRMgbF03z2ooAKINgbPqBtrjNQETMAETaDSBjSD8uE4e1kwARPMAv3eJ3zp9xDxWEzABE2gFAZUOfjeER+ribd0EwJnARnWB63GagAmYgAm0isBZEDaui8c1EgDRpsCP6gLW4zQBEzABE2glgc0gnFYHz2siAKI3ATcD2gKwmYAJmIAJmEBVCWgLYCkIj1Z1gGPjqosA0Ju/VgBsJmACJmACJlB1AqdB2Kzqg6yBAIjWBM6vOkiPzwRMwARMwATGEVgLwgVVJlJxARDNBtwCLFhliB6bCZiACZiACUwgcD+wJISnq0qm6gLgcGDHqsLzuEzABEzABEwggcAREHaqKqEKC4BoOeC6qoLzuEzABEzABEwgA4HlIVyf4brSL6moAIimA26I8yvbTMAETMAETKC2BFS3ZlkIr1TNg6oKAC2ZHFY1WB6PCZiACZiACQxAYGcI2tKulFVQAETzA7cCqvhnMwETMAETMIG6E1ClwCUgPFglR6ooAE4GNq8SJI/FBEzABEzABIYkcAqELYZsI9fbKyYAolWAy3P10I2ZgAmYgAmYQDUIrArhimoMBSokADqBfwqWWKoqcDwOEzABEzABE8iRgFLaL12VgMAqCYAvAN/JEbSbMgETMAETMIGqEdgBwpFVGFRFBEA0J3AbMHcVoHgMJmACJmACJlAQgceAd0J4oqD2MzdbFQFwKLBz5lH7QhMwARMwAROoL4HDIOwy6uFXQABEiwF/AGYcNQz3bwImYAImYAIlEHgJeBeEO0voq2cXVRAA5wDrjBKC+zYBEzABEzCBkgmcC2Hdkvt8VXcjFgDRqsBlowTgvk3ABEzABExgRATeD2FkR99HLQCuBZYfEXh3awImYAImYAKjJHAthBVHNYARCoBofeAno3Lc/ZqACZiACZhABQhsAOHsUYxjRAIgmqEb+Lf4KJx2nyZgAiZgAiZQEQJ3dAMC/1X2eEYlALYDji7bWfdnAiZgAiZgAhUksD2EY8oe1wgEQDQz8GdggbKddX8mYAImYAImUEECDwBvg/BCmWMbhQBQwh8l/rGZgAmYgAmYgAnEBHaBcFiZMEoWANEs3bf/ecp00n2ZgAmYgAmYQMUJPNJdBXi2rHGWLQB2Bw4syzn3YwImYAImYAI1IrAHhIPKGm+JAiCatfv2/6aynHM/JmACJmACJlAjAo92VwGeKWPMZQoAv/2XMaPuwwRMwARMoM4ESlsFKEkARG8A7gL89l/nj6XHbgImYAImUDQBrQIsCuHvRXdUlgBw5H/RM+n2TcAETMAEmkKglBMBJQiAaKbu2//8TZkZ+2ECJmACJmACBRJ4sLsK8GKBfVCGANgWKD3DUZHQ3LYJmIAJmIAJFExgOwjHFtlHwQIgUvvKc7xYkU64bRMwARMwARNoGIE7gcUhREX5VbQA2AD4cVGDd7smYAImYAIm0GACG0Eo7BlatAC4DliuwZNj10zABEzABEygKALXQ1i+qMYLFADRasBvihq42zUBEzABEzCBFhD4AIRLi/CzSAFwHrBWEYN2myZgAiZgAibQEgLnQ1i7CF8LEgDR24Hbixiw2zQBEzABEzCBlhF4B4Q/5e1zUQJARxe2yXuwbs8ETMAETMAEWkjgOAg6Up+rFSAAotmBewGV/rWZgAmYgAmYgAkMR0AlgheC8ORwzbz67iIEwC7AIXkO0m2ZgAmYgAmYQMsJ7Arh0DwZFCEAlLxg0TwH6bZMwARMwARMoOUE7oaQ67M1ZwEQfQy4sOWTZPdNwARMwARMoAgCH4fw87wazlsAXAB8PK/BuR0TMAETMAETMIF/E7gQwpp58chRAERvBe7Ja2BuxwRMwARMwARMYBoCC0P4Sx5c8hQA+wN75TEot2ECJmACJmACJjApgakQ9s6DTU4CIJoBuB+YN49BuQ0TMAETMAETMIFJCTwMLAjhX8PyyUsArAv8bNjB+H4TMAETMAETMIFUAp+AcE7qVSkX5CUAzgdyC0wY1infbwImYAImYAINJnABhKFr7eQgAKL5gfuA6RsM266ZgAmYgAmYQFUIvNzdBnhomAHlIQD2AA4YZhC+1wRMwARMwARMoC8Ce0I4sK87JlychwD4I/DOYQbhe03ABEzABEzABPoicBuE/+rrjnwFQLQCcM0wA/C9JmACJmACJmACAxFYEcK1A90JDLkCEB0JfH7Qzn2fCZiACZiACZjAwAS+C+ELg949hACIZgQeAOYatHPfZwImYAImYAImMDCBx4EFILw0SAvDCAAdQThvkE59jwmYgAmYgAmYQC4E1oago/h92zAC4HRgk7579A0mYAImYAImYAJ5ETgdwqaDNDagAIjeAOj8oX7bTMAETMAETMAERkPg78B8EPS7LxtUAGwMnNFXT77YBEzABEzABEygCAKbQDiz34YHFQBnA+v125mvNwETMAETMAETyJ3ATyGs32+rAwiAaBZA1Yhe129nvt4ETMAETMAETCB3As/H1XjDs/20PIgA8PJ/P4R9rQmYgAmYgAkUT6DvbYBBBMBZwIbF++IeTMAETMAETMAEMhL4MYSNMl7buaxPARDNDDwCaBvAZgImYAImYAImUA0CWv6fB8ILWYfTrwBYGzg3a+O+zgRMwARMwARMoDQC60DInKCvXwFwIrBlaa64IxMwARMwARMwgawEToIwJevFfQiASNcq+c88WRv3dSZgAiZgAiZgAqUR0Ba9kgJFWXrsRwC8F7gqS6O+xgRMwARMwARMYCQEVoJwdZae+xEA+wN7ZWnU15iACZiACZiACYyEwFQIe2fpuR8B8Dtg6SyN+hoTMAETMAETMIGRELgJwnuy9JxRAEQLAH/N0qCvMQETMAETMAETGCmBN0N4IG0EWQWAIv91AsBmAiZgAiZgAiZQbQJTIJyUNsSsAkBVhvrKMJTWsf/dBEzABEzABEygEAJnQVDa/kTLIACi6YDHgdnTGvO/m4AJmIAJmIAJjJzAk8BcEF5JGkkWAbA8cO3I3fEATMAETMAETMAEshJYAcJ1wwoAHf3TEUCbCZiACZiACZhAPQjsDWHqsALgYmD1evjrUZqACZiACZiACQCXQFhjCAHQqf73BKDfNhMwARMwARMwgXoQUFXAOZOqA6bEAEQfiFWEzQRMwARMwARMoGYEPgDh0l5jThMA+wH71sxhD9cETMAETMAETAC+BkHP8UktTQD8BljNFE3ABEzABEzABGpH4FIIWsnvVwBErwX+Bryudi57wCZgAiZgAiZgAs8Dc0D4x2QoElYAopWAK83PBEzABEzABEygtgRWhnBVvwLgy8DBtXXZAzcBEzABEzABE9gNwjf7FQA/A9Y1OxMwARMwARMwgdoS+BmE9foVAMr/P2dtXfbATcAETMAETMAEnoAwVx8CIFoEuMvcTMAETMAETMAEak9gUQh3T/SiRxBg9CnglNq7bAdMwARMwARMwAQ2h3BqVgFwOLCjmZmACZiACZiACdSewBEQdsoqAH4LrFx7l+2ACZiACZiACZjAlRDel0EARNMDTwOvNzMTMAETMAETMIHaE3gOmA3Cy+M9mSQGIHoXcGvt3bUDJmACJmACJmACYwSWgPCHNAGwBfBDMzMBEzABEzABE2gMgU9DODlNABwGTBMs0BgEdsQETMAETMAE2kfgcAg7pwmAi4HV28fGHpuACZiACZhAYwlcAmGNNAHwJPDGxiKwYyZgAiZgAibQPgJPQZg9QQBECwB/bR8Xe2wCJmACJmACjSfwZggPjHk54RRA9GHgosYjqLmDb3gDvOtd8IEPwH/9F8w3H7zudTD//DDLLBBF/3EwBHjuOXjwQXj2WbjzTvj1r+HPf4Y//QleeqnmMDx8E5hAYPXVYZ994J3vhNe8Jv7sn3suTJ0Kz6s6ui0TgUUWgfe8B1ZcEZZcEmadFd7+dnj5VQfJ/tOUvkv+8hf4xz/gX/+CBx6A3/4W7r4b/vAHeOyxV383ZRqEL8qbwEch/PsZP1EAKPhPQYC2ChGYay74yEdggw1g2WXjB/30ytYwpP3zn7EQuOQS+OEP4Xe/6/3HPWRXI7995plh++1h223hTW+CV14pd0gSYurz0UfjH4kxCTExv/VWeFIbb7ahCWyyCfzgB/Da107b1HXXxQ+z8QJ56A4b1ICYrbEGbLUVfPCD8cuEPrd5mD77zzwDt98OV18NZ5wBN94YCwVbqQR2hqBMvx2bKABOAKaUOhx3NikBPaT0Zfb5z8Pii+f3h5iEWwr94ovhiCNAX5ZN+aKcaSa4/HJYbrlqftj0JXjPPfHbkoSY2PtNtf+5mmOO+G1zttl63ztlCpx0Uv9tN/mON78Z9tgDNt4Y5p67PE///vdYDBx3HFxwAbzwQnl9t7inEyFs1UsAXAW8t8VwRu663vC1VPmhD412KLfdBgcdBD/6EWiloM6mN/+jjqqPB/oiPP98+Pa34y/IXkuu9fGonJHutx/su29yX9r20tZAU8TtMGT1hn/AAbDddvmsKA4zFn3mr7wSjj02/uy/+OIwrfneBAJXQ1iplwD4G/CqKEGjLIfAhz8c/zFqz61KpuXq//1fOOaY+i7Xffe78LnPVYlq9rEoZkP8zzzTX4pJ1GacEe6/P97eSbNPfALOOSftqmb/u7YUTzwx3k6smmmr4Kc/he98J94is1jLdYaehDDHJAIgmgd4ONeu3FgqgYUWghNOiPfeqmyKFdh7b/jxj+v3B/mb38Bqq1WZbvrY/vY3+OIX471T75tOy0tsvvWtdI664qabYJll6vc5zuZd8lXa59eLxo47lrOtOOyYtaWjFYpf/WrYlnz/OALzQnhE/3tcDEC0CnC5MZVDYIYZ4uXKXXYBBajVxS68EDbdNA7oqYtpb33lhtS21BL2NtvEMQ22/xBQ9LnEdFbTSQEJwzaZTgppr72OYliCJavAa9OcDujrqhCumCgAFPynIEBbwQTe+tZ4ievd786/o8mWy/KK5B0brY5VfeELsQ91sCYJAPFWRLViM3bfPT7i1nb72MdAwrQf0wmMUcfZ9DPeYa/Vw1+M3v/+YVtKXjnJ+7tmbLQSvtoedXDs8PMHbAXhxIkCYCqwZy7Nu5GeBDbbDI4/fvi3fp21VeS49oh1xvb3v49/TxYwNt108La3xVHwOserM70SITojPahJaCiwbuedq59LIKsAKGOvMc8vSK3C6KTIL34x6Cw2474rroD3TVPpPN23FVaIT1w03bTC+POfD/bw19n+66+Pf669Fv74x+QtKH2nLLhg/F2j3/qe0SkD5RQY5uiy/jZXXTU+KWMbmsABEPaaKADOBDYaumk30JPAN78Ju+46GCC99ekBrwhZBTDdcstwaljJhPRHqjO/66wTn/kdxK65BhTAqHPtVbU0AaBjSEceWc5pBx1JXGKJ+GeVVWJBNuecg5OT4NOpEUXAl53bYPBR53enEmH93/+BttT6NSUHWnfdfu+q3/U6WrqFarxmNH2mzjsvPp6nrSYlEhvWND8SA1p1URCmTjvp2GZW00kkfV9prm1DEzgLwsZqZXwMwPXAskM37QamIaA3cO1fadm8X9Mf38knx0fytM9ZhCmCWnuiOi6n6ODJkqgk9XvDDbDRRsWNb1if0wSABJC+8EZhWhFYdFFYc03Yeus4w+MgqwTa2/30p0HBgm0yRbJvueVgHmsVbeGF4aGHBru/DnfpbL8CR7OY3rKVI0GxSX8tOCG8vhMl3pSX4ZOfjLOZJtmll8biwQGwWWaEDFt+AAAgAElEQVQy9ZobIXSe9eMFwOPAEO8iqZ228gIte2mvfO21+3Nfy7v6Q/ze9/JR4Fl717Ld4YfHKr2fJTs9eLS/qKx2VbM0AbDWWnFwVBVMDyTt7WurqN9VGQkxCbi2iIB554W77orTYA9qOmqmEwRNtNlnj5fsxSnNHn88fhArEVjZJsGrDI3aTtRDfmIip0ceif9/rXraciHwBIS5xgmAaFbg6VyadiP/JqAPthT1Zz6THYreSpSJT2/8o0wPq+VpCQEdl8pq+hJRkhX9rpKlCQCJM22tVMn05S0hoFUZ5WDPajffHG/J6Euz6XbggTGjYUwJaN7ylup9Zofxaexe/f0qej7NtI2nWJL77ku7svh/f/3r4+0KHf1TjgL97SobapNXaYqnOmkPs0F4prsCEC0J3DyigTS220MPjVVtVtMev1R4Vd6itQKgbYtvfAMUM5DF9BaqIkVK81kVq6MAGGOnxDZKZLThhtlpKse6RECTVwL0ebz33uR9ZC0X60dxF0n2pS/FWRebZNpf10NT23tJpoe/cpA4ur5Js5/Jl6Ug3DImANYEKvYOlMmJyl4kBXv00dmGp+AtqXUl2tEKQNVsqaXiI0QLqFh0BtMDV8VEquJLnQXAGO711otPXWRZztU9itrW8bgnnsgwYTW85MtfhoMPTh74qafC2WfHe+BJQYKqWqcAtSbtL2tlRCskSaaVuv/+bx8lreHHP48hrwXhgjEBoESp382jVbcRB3XpbT5LMJ2C/LRF8JOfVJuclqQ1Rr3dZzFFEKvyXhWsCQJAHFWoRVwVn5HFlOhGIqAqQizLmLNco4e5AmKTBKki2d/xjviY7Omnx0vcSabPqtg2xVRDQvvqSabA037zJzSFj/3g8xCOGhMA+wOdc4G24QjoHKyWwfXWnGba41fgXF2CWyRotFKh1Y0skeqbbw56Cxu1NUUAiKO4aw60bJ3FDjsszjbZJNOpjZ/9LPkzOD7RjxLI6G8y6TOrVNcSDE04SqmYEdXwSHoB+eUv44BRW2sJTIWw95gAUIHMz7YWRY6OK8+2SmumWd0e/uP90VaF4gLSTD5qNWSUwYwaY5MEwBhz8dc8pJnehBVXohoOTbHLLouTwiSZtqDGItr14FdRmbTMm9pmkbCouy2/PGhvP0nwKHGSqu/ZWkvg+xC2HBMAFwEfbi2KnBzXm4aW3tICbxQgt9JK9XnznwzPKafApz6VDk5FPD760dG+WTVRAIi8zngrJXDacU0JMCVeUWGVupuyWCrIMSmLpR5sOsUyPrOjEv6kPdxVJKhq1TgHmS9FzSuxVS/TGX8d97W1msAvIXxkTADoBIBOAtgGJKDEFkrHqy+oJFNqzfXXr8658wHd7YgcnZ3Xm1aajXoroKkCQNz32ScuF5xmEmLa81VGtTpblsQ/Sko1ccVDb8P6+0zbmlO2OW0X1NkU9Chx2MsUGLnBBnX20GPPgcAtEJYaEwCPAZ3EALbBCCiQ7/vfT793hx2S1Xl6C9W5QkexdGQxrQqbCtYsthjozPUorMkCQDyznvdW7Maxx45iBvLpU2+tt9+enPhHZ9m17TRZRH+WVQAJJR2hrLMpVbjiJHrZD34An/WGb52nOI+xPw5h7gCRsmi/9OqsgHm03542tBypwjxpx+S0d6ko+jKKzpRFXznt9YCdmL1rYv96U91foaYjsKYLAEXF64RG0pe+sD/8cLxCVbVETVk/Ejr2p+N/SZZ0pl+rAMoln7ZKp3+vSi6OrGzGX6fMo0knRVQboJ/kZIOMwfdUnkAEzCgBoESRDc6GXfxEKFmOUoom2dNPx1HG+hJumukI1THHJHul444SSOJQtjVdAIinEr/ooZWWU/1rX4sLB9XNlO5XR/qS/HvqqfjfX3yxt3faHjhTZc8STPkWtI9eV1P20aQ3fK8A1HVmcx/3fBIAzgI4BFft/d9xR7zsmGT6g9QfXhNNb1a33RZXtksynZDYawSHTdsgAMRdwZaKy9BnspdpG0YBqNoPr5PpKOMhhySPWFUR005GSEgo8c8b35jMqM7pgbfZJnmrRysEikOytZ6AYgAipXa5pPUoBgSgRCtpyTQUXayc+k1a+p+IS/5ddVXyCQgtPeuLtexYgLYIAM2J3l5VPyDJFKsyaAW9Af9MhrpNgkaJtbSC1suU7EjV5bKcdFB6bqXpTrKvfCXbUdehHCvoZp3v/8UvejeuFNHKKFn3gNCC8LWp2dUlAJRl/Kw2eZ2nr5dckp4d7+Mfh5//PM9eq9lWlgjt//kfOP74csffJgGgWAytSKmGQC9TpUlFwyuXfh1MDzT9/SSda+9nWVsFZ3QULmkV4P7741W9Oj4klQjosceSxbhWgXRk2dZqAhtJAGwD1Dg2eHQTqGpVWk5MMi21Lr306MZYZs966CijWlL1ulGshrRJAGi+tc2SFnCpa7QlUwdL29OWD4rcVwR/VttpJ1CWxCT73Oey1/PI2m9Z1ylVctLpHB2TVDyErdUEtpUAUEHNlLIRrYbU0/kswW9VqjVfxix+61vJ9dW1DaKlXL2llmVtEwAzzxwHBC6ySG/CEmoqBFP2dky/c/6ud8VZ/JKSa116afoq3MR+tQqganmzzNJ7RH/6U7ytUMf0wFpl22qr3r7JJ4mmsWyJ/c6Lr28EgT0kAPQekCF5bSMcztUJVVxThrVepj3veeap5xfIoKAWXzwOCEwKRFMaW+2xlmVtEwDimlYtT0JMDwDlzK+yqUyvcmckmY686ex7v3bQQbDbbsl3KWGOEufUzZTRUBkTk0xbQBKBoziZUzeeDR3vgRIARwEpYUMNdX8It+acM95nS9qXHOXZ9yFcG/pWvX3qza2X6e0/7cTA0IMY10AbBYCEp95gk/IzZImaz3Me+m1LFSjvugv0u5cpOFAPMdU86Nd0ZFBHC3UyoJdp9UEBrnUzCXA94N/85uSRK4ZJMUpNqxhZt/ka0XiPlgA4BciQ1X1EQ6xot1raP++83oNTJjLVGE+LEaioe0MNS0cetW/by/RlPddcoHPbZVgbBYC4KjeFclT0Mm0DqEDO88+XMQv996GiWmlxCp/+NJx8cv9tj91xxBHplRXrmh44y9FJcdCxQCUGevbZwTn6zloSOFUCQItnCYkja+lY4YNW1LG+fHpZXd8c8gCnIEBFWSftr06Wrz2Pvidro60CQAVxLr+8N1VtA6yxBvzmN0WRH7xdZdfUSpFEdC/TCpwC3YaJY9AqgLJ4JpXO1VuyONXN9HeoVSAd+UszbRdsuCEoeNDWGgLnSgBcDKzeGpdzclRLh0nJf77+ddh335w6q2EzOoecVG9c1QS32KIcx9oqAFSrQalvk4IBtQf+zW+WMw/99KJENYpUT9pi23FHUNDpsJalsqXyV+hoYN1Mf4NKDpVWMVJ+KVunTkYoR4LjAuo20wON9xIJgGuAFQa6vaU3KSJZJX2TSpJq31CrAG21tKNoChRUhHUZ1lYBILZpiYFUTjhLWecy5ml8HwpOTHrrVrpfpZZWUpthTYGriiVQTYVepiJKKqZUR0s7mTPRJ63e6Z7jjgPljLA1lsC1EgAuBdzn/CroKCmVqr6clGSkzYE1yn2gZcVeb3BlMmqzAEg7qqq8DCuuCCpTXRXLklUy7weyIv3XW683gVHWshh2XvTCcvrpyf5N1odWPI4+Gk47zVsDw85BRe+/RQLgz8BiFR1gJYelo0ET642PH2jZUe5VhKQ9Ve3RJsUBqESworyLtjYLAGX8k1jtJcS0f65rtKVVFdNDJ+1te9VV4Yor8huxclP88Y/JWw5KHqSgwTraoCJAvuozooBnxULouGUTC5rVcU5zGPOdEgDa2Uo5LJJDVw1q4sgjk6uFqTSrAmrabmnHAfvN3jYozzYLAAkwCYCkOIAPfag6+QB0fFHbQ0lH/5QWeM0186+tce21sPzyvT9lCpCTaB3kyOGgn90875MIOOEE2HzzwVvVloAyLkp8KQGTggyTqi8O3pPvLIHAXyUAHgXmLqGzxnShqOnVVuvtzhe/mF4euDEwEhxRkSQVS+plZXFqswAQ+7SAzFHUZ+j1mVC54q9+NfmvQ5+ppGI3g/5tSVScf37y3Z/8JJxxxqA9jP4+rQTpmO7BB8dHcYc1iTUxk9i/4YZ4q6Cqx0qH9bWB9z8mAaDT2LM10LnCXNK+qc5P97IqvVEVBiFDw2lLuTqnLhFQtLVdAKSddddDd7/9ip6F9PaVkEfBeElH/xRXssIKxbyFK3mOVkuWVIH0HtaU2h7a8lCuDrFMOmmRPmv/uULphZVbQqsD4nTllXD77V4h6Idhydc+LQEQldxp7bt75JHe1dZEU9Ht+uC33fRmqUjiXqY3h7XXLp5S2wVAWlpgJdvRqY1Rm/JqKL9Gkm22WRyUVpRtuinoZESSvf/9yfkVihpb3u3qaKC2KjX/Cy+cd+vxk0UrA/o716rpNdc42VD+lIdr0QJgAH7KYNcrxapUsNJvqtBI2y0tWFJBV0kpg/Pi13YBoGyAWm3pZXoTnDIlL9qDt6O95Q9+sPf9990Xp5Aucs9ZuROUQneOOXqPQ58nJVlqiunE0pZbxjUXihACY5zEVcHTiuFQKWJvFYz+E2QBMMAcJAkAHafSl0gd64gPgCLxFkWXa7ukV2EgrZJotaToNai2C4C0lZgqBK2qqJaWjJOq/m2/PRxzTN6f0mnbU4Khww9P7kdCpMyKlsV7HZfx3nhj2GabuP5BUkGvYccjdlrt0WqLsw8OS3Pw+y0ABmCXJACkaiUAin6oDTDs0m+Ze27QW9tMM03etQVAOVOy7rrws5/17uuss+Iv/lFaWryIEm8tuGA59SP0IHzwQVDJ4F72ve/FD8ommrYGPvCBuD6AtjvEvShT/QGdTFDCKsUP2MolYAEwAG8LgGzQFGWsZb9e1dYsALJxHPaqtJoAoxYAysev4L+ko39689cKQFmmFQCtBPQyPbi01df0THkSQyq3LBH5vvf1jn0adl704iQRoFTE3j4dlmb2+y0AsrPqXKmIWQkA/WFMZl4B+A8VC4A+P1wFXV51AZDl6J+O3V52WUGAJmlWouTuu3uvXukWVdvTA6stphLomgeVD1a+BG3f5b1N8MQToDLV3/42qKKqrVgCFgB98pUAUKGMXhnuLAD+A9RbAH1+uAq6PK109ShXALQ6dMstyYmKFEW+zjrlb6v98IfJBatURVB1BNr4oFKmT4kAHSNUuWTFcOj4Zl6C4Nxz41LWdSzAVNCfcSHNWgAMgDVpC0BpM7V36BiAuFqiMoX1qkTmLYABPnwD3LL11qA96142yiDALEf/tPysB0LZpqx/+owmVdLTsUHl2W+7Ke5JQmDllUFpmrVdMPPMw1HRw1+1LHRqwFYMAQuAAbgmCQBF/2t1oM2FgMaQqhRpUsY2ZRHTMcCixVLbTwGkHQNUNLayw43CLroIlBK6l+moqApLjapYUVqRIJVbTkoKNgqmo+5Tq6QST/r719wqMVqvQOC0ser7dNdd4y0BW/4ELAAGYKotgF4xAHqYqXa4Smq23dKOnymXuKKNi7a2CwB9gX7zm70pH3gg7Lln0bMwbftaQlbWuKSjfzqf/v3vlz+2sR7f+1646qrk/puSGKgoyso6qC0cnTTR8cJ+TblVdt45LlFsy5eAUwEPwFPnVhdaqPeNemNJKhc8QJe1vOWQQ+JAqV524omw1VbFu9Z2AXDoofEXaC8bVSrgtKJaEtHvfCfoCOCoTMv/Sj+sEuC9TAJBS9+2ZAISeopHUfpviaZ+TCLg858vJw9EP+Oq+bWdVMAuBtTnLCphyUor9b7J+4IxG+2NbrJJb05f+Qp84xt9wh/g8rYLAAXRqdBNLysrwc74/nVCRGliVf2vl6k+gcTJqC0tTkEPJyUGqlJJ5VEzS+pfokopwHXMsh8hoPiqj360GWmYKzI/nWJALgfc52yceiooJ3kvK/vMcp/DL+3y66+Po4N7WVnBXW0WAIpH0Rvs297Wex7KKss8fgQSf1//eu8xac9fe+uKExm1iaGOBCZVz1PBpZ12GvVI69W/hIC2BbQFpW3TLKbPw4orNj//QhYWOVzTKQes/EuL5dBYa5pIC6oqa2+76sAffxx0driXqeqa3gKLtjYLAL2ZivEMM0xOWQ9apWzWaY2yTEfIfve7+Bx5L1PO+I02KmtE6f2kpQdW8hqdetFbqq0/AloFUozKFltku2///WGffbJd66sSCdwpAXAzkFAA0wgnEtDZV1W26mU6JaAHn5YG22oqpvLww/Ca1/QmoMxvYlW0tVkAqH59UvW8m2+Oz3IXWWBn4vyuvjpcfHHyrCvZTJWOf6n41wMPJKcH1ovBd79b9Ke5me3r5ICqVh50ULp/zz0Xx2TcdVf6tb4ikcAtEgB6lK1gUNkJqHqWMlYlJb3Q24CWDdtq2nPW3nMv+9vf4iXVoo8Aqv82CwB9oe62W+95OOMMkEgo004+GTbfvHePEtfKXli1BDtpQa1aRdGqRpuF/7Cfo7SVlrH2Fdiq0y22oQhcKwEgLb76UM208GbluE/at2pbmtCJHwElnlECml6m0q9J57/z/Ei1VQBo9eW665LPqe+1V1wPvixbYglQbEjSuXC94WkLQKtD2i4Ytb38cvxQX399WGCB5NHomp/+dNQjrnf/afEh8k7bizohot+2gQlcIgFwDrDOwE209EaVsVS0fy+79to4WKWtpohorYL0Mh0FSqpRnye3tgoABdFpr13Lq71MyVp++cs8aSe3JbGxxx7l9Vd2TxI3ym9gG5yA4lVUvTLp5IpaV56R448fvB/fybkSAKcAnzKM/ghssEH8ltLLlMFKbwuPPdZfu024WhHnSqGatEWiPTztP5dhbRUAOvuvpdJepj1tBQBqO6YMU8yHMucVWV62DD+S+tBKwXveE/tpG5yAEgZdfXVyDJFOYyVtJQ3ee2vuPFUC4CigxEKbzYCrPNePPgrKgd3LtEeV9AXcDBLTepG276wlXgUJlpXetY0CQEvn2ktPSlNbdhGgKVPi2u9NNz+Y8pnhtGJMShQlAfvkk/n018JWjpYA0A5ggxfliptWLZ0qz3Uv09EgrQKUEehWnJf9t6zo3EUW6X1f2cck2ygAPvhBUJxFkikLo7IxlmUXXggf+1hZvY2uHz2QlCn02WdHN4Ym9KwYIdUS6bWFpe9VZV31asvAs32gBMDuwIEDN9HiGz/1KThFGygJtsYacMkl7YGkKmDK755kSqKUdDQtb1ptEwD6wtT2lALSeplWr1SIqawgKq1EaEWiCkF9eX++JmtPJy+S6i+UMYa696FVViWxUrBfLxt1rYiaM95DAmAb4NiaOzKS4esDqj1+lf/tZfrSU0GRttgFF4DOcPcyxUZo+b/M/O5tEwBKUy2fk4L/Dj88uT5A3p/XtHoEefc36vZ0JFAPrrat/uXNPe00UZnBxHn7VoH2tpUA2BA4qwKDqeUQVEpVucJ7mb4AVPHusstq6V5fg9YZ6JtuSq7uNopz520TAD/5SfLbvwLVlIynrM+kkmLdcgvMN19fH6faX7zeenE0u21wAkoXrWOBvWzqVNh778Hbb/mdG0kAqCBrixap851yHfnRkb8k0zKWsq3pPHGTTeefP/GJZA+1B6x9vTKtTQIgy9u/Pq+qXlfW5/Gzn4WTTuo941oV0paF9nKrlvxnslHrdIvS16rQ1Zvf3Nsv5WDQ371tcAJpOQGOOiquEmgbiMDqEgBKA1zSgayBBln5m/SFmnb2d5ttQMtZTTXtJ+vMeVJtd2VG1LJoWdH/Y6zbIgDEXvEXaZ9FHZ1SpHpZlhb8d/bZcTZCCYE62ec+l5z6VystKoalVTHbYATSBIBSLysFs20gAktJAMwLPDTQ7b6pQ0BL/GmBfooM1kNSJwOaaDrTr+I+SbbddnDsCKJN2iIAlNVPhVKSTKtRikkp62GrfA96E04ShnXNnqcqgX/+c3JJ429/G770pSb+xZfjU5oAcOXVoeZhPgkA1Ql7CUjIFzZUJ624WcVNtK+aZFdeGde/LmvptSzwquKlM7tJpmDJhRcG5QAo29ogAPS5uuii9Ch7nVxRFsuyLC3474474qNczz9f1ojy7WfPPUH70L1Mgl8VGX0kcDDuKhW8u86p9TAJhG98Y7C2W35XBMzYfehHylc3V8uBDOW+st/98Y+9y66ONa6jQUnFWYYaxAhuXmyxOGNXUq10DUu10lUzfRTWdAGgXBNXXZVeU/3cc0GBaWUVq1Hwn0oRz6s1xh5W99Ku+tzfdx/oRFAv22EHOPLIUXzy69/nOefAOgmJ6rW6olUWW98EHocw95gAcEngvvlNe4P2o7QvmGR6+1caYX2w624q6KLArcUXT/ZEe//a/iiz5Oz4ETVZACggTWVz0worqU69alOUlX5Z/D/zGfj+93t/NhTwpyA5xY7U2dJOAunFQNtjZQmvOrMcP3YVW9P3i6qv9rJ11wUJW1vfBG6FsOSYALgI+HDfTfiGVxHQW4COOyUVwdENOgMvVfub39QXoB48Om6WFvUvD1ddNT05UJEkmioANAd6+GTJh65l1IMPLpLyq9tWDgKVg07KCaFtMwmXuj8YtbWl4le9al/oKPBHP1pu0aXyZrq4nrbfHhTl38sUTCxhpW0kW98EfgnhI2MCQId0Ptt3E75hGgJ62CkgcPrpk+FoT1APz7TgwSoi1hedMvltvHH66HS8a6ON0q8r8oomCoB+Hv7yX6mB//GPIim/um1l/tPpmKTgvyZlcdPpC2XB7GUSO5oDWzYCeplS8KjKR/cyVV7UcdayAlqzjbw2V30fwpZjAkCxw3vVZugVH6iyrO24Y/ogtRKgJaw6iQAJGz38szzUFfj3jneUV22uF/GmCQAtiSqHv/bz00yfMS2zaxm6TDvkENhll949KjhOX+5lVSIs2neVBk8KrpT40jaY6mTY0gkow9+3vpV8XdPiqdKp5HrFVAh7jwkA7Vx/N9fmW9zYa14TL+9LnaaZouJV17rM3PhpY+r171LlGqdESxbTqYgqbHM0SQDooXn66fHDJM20tK59+LR6FWnt9PvvCoxT8J+S5fQyxQZoBaAppnTg2gZICnj82tdgv/2a4nFxfuiYqk606JhlL9Nne5VV4uBX20AEPg/hqDEBsCZw/kDN+KZJCcw2W/zWNf/86YD0YT7++HjVQMFaVTRlPNNKhU47ZLGyc80njakpAkBvRYqaTypBPZ6DUqQmHVHLMo+DXKPU2IpN6GXaE1dGSH3JN8m++lXQQ76XlREMO8MM8YkbrUio8NJf/hLvo6tGRx1MAkpL/wsumDxafRepEmvd40dGOCdrQbhgTAA4G2ABM6Hlb+0Nph2RG+v6/vvj4MDf/76AwQzR5Nprx1kMk97oxjd/3nnxSYeq7M3VXQC89a1xxrmkgLqJ06stAq0slf0FmSX4T6sDyy03ulMhQ/wpJN6qh9e99ybHPWhOJPaLMs37ZCsrv/51vPqgXCRVNQVP63RUltUtfScpyNQ2MIGlINwyJgBmBZ4euCnf2JOAUt9efnl2EaCjclLsKoLx9IhnRG/93/lOLEp6RThPdFyrHjpuVqXEJ3UVADrfr8+Bculn5a/50PK6HjSjyKufpSCUYgMOO6yZXxonn5x8KkNL1lm2BgehkxaArJUXBSNqb11HR6uUkEzbiscdB296U7rneqnS9uIoPt/po6vNFbNBeGZc9r/ocWDO2gy/RgPtVwTINaUOViCV3vzKFgJasVCGMz1EkvbhJk7BbbfF+3JPPFGtyambAFDmuD32AGVYTDtNMpG0lt633np0X45p1duU8U8nBJRCt4mWlhZcDy3tcd9wQ/7eKy3utttma1fbEYol0cvGAw9ku6eIq/T9ogRh2jbS9kWaaUVLR0clZGwDE3gCQifx33gBoI/kMgM36RsTCQwiAtSgHv4nnABHHx0HGRVlWrrVsqzy9Wv5flatCfVhevPXG0jVHv5yIU0ArLXW6PdIFVuhL8E114wfkJqPfk1vdrvuOrqHvwLhlGhokUV6j1zlcbOcXujX96pcrwBgbeFpJaSXafUj6YTEoL6kJSSarF0JEh3XVCVPBfg++OCgvfd339xzx0JVidOSKipObFW1RPQdZRuKwA0QlpsoAM4ERnxieyinKn+z9ri0Py4xMIgp5agiusdKpw67v6svKx0RmzIlDspKimBOGq/2FfXgKnulIivDNAGgL2S9hZSxJCrmCnBaaqm4UpyyKCpWZI45Bnvoi4FiLfSlqP3fUZrOuf/qV8kj0KpG2acSymaSlsBGRyAlEJ56Kt+RqaLiMKeJ9Pm//fb4R99TesuWIBj2e2bMSy3vKyGSKqNqFaSfbS21IaGiz5iOttqGInAWhE4Wl/ErACppsedQzfrmVAKve1289KYglmHsmWfiDFh681a6TAVWaQle+3wTTW+TOpWgh43e8pW/X19AelNTOt9hTGVl9Qdd5WIuaQJA/utNqGgBoHnQkn6/y/pJ86PlWz1Uq3DcMu0NVGPVMca8H3zDfH6LuFdvtwoGTKoPoC2egw7Kt3d9rrS3r+j4PEzfJfqeUe6Cv/41Fgb6jtGPREySMNDSvkSuqkHqJUPZEhdaqP+H/pgf2rLQ9opegmxDEzgAQifvz3gBMAU4Yeim3UAqAf2h6qiOjgxJEORleoBN9hCT0lafgywr9xqbvsS1jHnSSZOLjrx8yqOdLAIgj37KbENfzqrAuPPO1Uimoy/3P/wBtA3Qy9q0fKtATOVg6GWKAVh++fz/diQ6lCDn858v9tOo7xkJgF4vHPq+6fcNv9eIJUDWWCMWVbZcCGwFobNeOF4ArAJcnkvzbiQTAb2RazlUb+V1Mu1xasvg4YfrMeqmCQC9SWvJv0rHoLbaKvl4mx4W+sz88pf1+MwMO0o9sHT0rpdp22allYoJBlSfEhcqpcWfZdMAAB4JSURBVKu35jqbGKqE9aOP1tmLyo19VQhXTBQAyttVk6/0ygEdeECKfNWX+T77ZD9nP3BnQ96oB75WLRSUWJUz/llcuuyyOECx7ib+qn2uvf6qJYw64ID45EIvU3CgloJHVRGy7LlXEh5t0amiXS9TYicdsy3SFGeieVl//XxXAIscs9rW50QnSg49FFT0x5YrgXkhPDJBAOh/Rn8DZs+1KzeWiYC2AnT0TrXDtV9fJVO6YiUC2nffeE+wbqajTgrMqqtp31PLuhJeVXvwjzFVkhl9PnrZbrvFPrTJ9torztzYy/S3fuSR5RBR4LH6U6Dg7BX/hleRH8W1/OlP5bBpWS9PQphjzOcJh40iZVZ+b8uAVMpdpXnV3roeWFkz7xXlgJbd9NDRF7fyEtTVtIRYt8hzBSVeeCF8+9v1OPOs5WxttUwWZyIBqeRQClRtk+m0h4LXJjvfLiGnrT/FTZRp2pfXOfovfxlWWy2/ffo8fFApdb0EKZAxr5MHeYyrYW1cDWGlXgJAQYAKBrSNmICOiynb1Ze+FP/WkmIZpi8mZdrSG7+OApVZQrYo/8RS58/7SaVb1Fh6tasvPKWCFvszz4yzR1b1WOVkPujBrxMhykE/3iRkFJCmLG9ttMkqgypwTls5qh0wSlPCLwkzZZpUzIKqTJZtWt7X0VG9ZOiz7wd/4TNwIoStegmAnYCGJuksHGxhHejhr3OzShSjP9SkfcV+B6EvI5311T65jnHpj7Cqy8z9+jb+ekWnaxlaiUf0RTdZ9PIw7We5Vw9J9auETnorVjCfljvFXEerVD65zqbP6Ve+EmeQ1DaW/NQy+Lnn1tmr4cauaHi91SrOR8cDdZxOx/+qJoi0MqAMlAoa1Fl7JaPS90yeR1bHSErYKseATrFI6NZ5dXG4T8dI7t4ZwuG9BMBHgF+MZFjuNDMBbRPofK3+YN///rh4hh5w880XHyuc+HDTH7fqruvLR398+mK+9NI4h4CO2FQpb39mCENcmPeRyH6GorkpOt9AP+Mp6toxsVNU+3VsV3+HdXrDnXHG+LtFeUOWWSbO4aBkYfr/9buXkJaPOiasFwsF86kiobaHbrwR7rmn/kK3jp+9cWP+CIR/n8WZGAOwAPDXmjvY6uHrS2ayfdg2PHRaPfF23gRKJtDru0Yit05Cp2Rso+7uzRD+Xf1hkozjkcK9RrAbNGou7t8ETMAETMAEGkvgKQivOgMymQBQnaXVG4vAjpmACZiACZhA+whcAmGN8W5PJgAUBKhgQJsJmIAJmIAJmEAzCBwOYec0AbAF8MNm+GsvTMAETMAETMAEgE9DODlNALwLaFnKDn84TMAETMAETKDRBJaA8KrUU5NtAUwPPA0k1PVqNCQ7ZwImYAImYAJNIvAcMBuEl1NWAPTP0W+BlZvkvX0xARMwARMwgZYSuBLC+yb6PskKQEcAKFPQji0FZbdNwARMwARMoEkEjoAwTXB/LwHwKeCUJnlvX0zABEzABEygpQQ2h3Bq1hWARYC7WgrKbpuACZiACZhAkwgsCuHujAKgsw3wODBnkwjYFxMwARMwARNoGYEnIMw1mc89tgA6AuCnwCdaBsrumoAJmIAJmECTCJwDYdJneZIA+DJwcJMo2BcTMAETMAETaBmB3SB8s98VgJWAK1sGyu6agAmYgAmYQJMIrAzhqn4FwGuBvwGvaxIJ+2ICJmACJmACLSHwPDAHhH/0KQB0efQbYLWWgLKbJmACJmACJtAkApdC+EAvhxJiADoCYD9g3ybRsC8mYAImYAIm0BICX4Og5/ikliYA9PavVQCbCZiACZiACZhAvQisDqHnMzxNAMwMPAHot80ETMAETMAETKAeBF6Ic/kE/R5kBUD3RBcDq9fDX4/SBEzABEzABEwAuATCGkkkUlYAOgJgL2B/4zQBEzABEzABE6gNgb0hTB1WACwPXFsblz1QEzABEzABEzCBFSBcN6wAmA5QXYDZzdMETMAETMAETKDyBJ4E5oLwypACoLMNcCawUeVd9gBNwARMwARMwATOgrBxGoYMMQAdAbAlcGJaY/53EzABEzABEzCBkROYAuGktFFkFQALAH9Na8z/bgImYAImYAImMHICb4bwQNooMgqAzirA74Cl0xr0v5uACZiACZiACYyMwE0Q3pOl934EgI4C6kigzQRMwARMwARMoJoEpkLYO8vQ+hEA7wUmLSmYpSNfYwImYAImYAImUDiBlSBcnaWXfgSArn0ImCdLw77GBEzABEzABEygVAKPAPNBiLL02ocAUHORTgLoRIDNBEzABEzABEygWgROgjAl65D6FQBrA+dmbdzXmYAJmIAJmIAJlEZgHQjnZe2tXwGgqoBaYpglawe+zgRMwARMwARMoHACz8Zb9L2r/00cQZ8CQLdHZwEbFu6KOzABEzABEzABE8hK4McQ+srYO4gAUHrBM7KOyNeZgAmYgAmYgAkUTmATCErbn9kGEQBa/n8YeF3mXnyhCZiACZiACZhAUQSeB+aFoG2AzDaAAFDb0dnAepl78YUmYAImYAImYAJFEfgphPX7bXxQAeBtgH5J+3oTMAETMAETKIZA38v/GsagAuAN3aRA+m0zARMwARMwARMYDYG/d5P/6HdfNqAAUB/RacAn++rNF5uACZiACZiACeRJ4HQImw7S4DACYC0gc8KBQQbne0zABEzABEzABBIJrA3h/EEYDSMAZgRUb3iuQTr2PSZgAiZgAiZgAkMReBxYAMJLg7QyhADobAMcCXx+kI59jwmYgAmYgAmYwFAEvgvhC4O2MKwAWAG4ZtDOfZ8JmIAJmIAJmMDABFaEcO2gdw8pADqrAH8E3jnoAHyfCZiACZiACZhA3wRug/Bffd817oY8BMAewAHDDML3moAJmIAJmIAJ9EVgTwgH9nXHhIvzEADzAfcD0w8zEN9rAiZgAiZgAiaQicDLwIIQHsp0dY+LchAAajnSEYQ1hxmI7zUBEzABEzABE8hE4AIIOoo/lOUlANYFfjbUSHyzCZiACZiACZhAFgKfgHBOlguTrslLAMzQ3QaYd9gB+X4TMAETMAETMIGeBFSNV8v//xqWUU4CQMOI9gf2GnZAvt8ETMAETMAETKAngakQ9s6DT54C4K3APXkMym2YgAmYgAmYgAlMSmBhCH/Jg02OAqCzCnAB8PE8BuY2TMAETMAETMAEXkXgQgi5BdznLQA+BlzoCTMBEzABEzABE8idwMch/DyvVnMWAJ1VgLuARfIaoNsxARMwARMwARPgLgiL5cmhCAGwC3BInoN0WyZgAiZgAibQcgK7Qjg0TwZFCIDZgXuBWfIcqNsyARMwARMwgZYSeBZYCMKTefpfgADobAMcC2yT50DdlgmYgAmYgAm0lMBxELbN2/eiBMDbgdvzHqzbMwETMAETMIEWEngHhD/l7XdBAqCzCnAeMHSu4rwddnsmYAImYAImUCMC50NYu4jxFikAVgN+U8Sg3aYJmIAJmIAJtITAByBcWoSvBQqAzirAdcByRQzcbZqACZiACZhAwwlcD2H5onwsWgBsCJxV1ODdrgmYgAmYgAk0mMCGEH5SlH9FCwC1fweQa/KComC4XRMwARMwAROoCIE7gcUhREWNp2AB0NkG0NGFY4pywO2agAmYgAmYQAMJbAdBR+oLszIEwEygFIbMX5gXbtgETMAETMAEmkPgQWBRCC8W6VIJAqCzCrAzkGsKwyKhuG0TMAETMAETGCGBXSAcVnT/ZQmAN3RXAd5UtENu3wRMwARMwARqTODR7tv/34v2oSQB0FkF2B04sGiH3L4JmIAJmIAJ1JjAHhAOKmP8ZQqAWYE/A14FKGNm3YcJmIAJmEDdCOjt/20Qnilj4CUKAK8ClDGh7sMETMAETKC2BEp7+xehsgWASgRrFWCe2k6PB24CJmACJmAC+RN4pPv2r9K/pVjJAqCzCuATAaVMrTsxARMwAROoEYFSIv/H8xiFAJi5uwqwQI0mxkM1ARMwARMwgaIIPNB9+3+hqA4ma3cEAqCzCrAdcHSZjrovEzABEzABE6goge0hlJ4xd1QCYAbgD3GeY5sJmIAJmIAJtJaA6uW8C8K/yiYwIgHQWQVYHyisylHZIN2fCZiACZiACQxAYAMIZw9w39C3jFAAdETANcAKQ3vhBkzABEzABEygfgSugzCyZ+CoBcCqwGX1mzOP2ARMwARMwASGJvB+CJcP3cqADYxYAHRWAc4B1hlw/L7NBEzABEzABOpI4FwI645y4FUQAIt1AwJnHCUI920CJmACJmACJRF4qRv4d2dJ/U3aTQUEQGcVQKWClSDIZgImYAImYAJNJ3AYhF1G7WRVBMCcwG3A3KMG4v5NwARMwARMoEACjwHvhPBEgX1karoiAqCzCvAF4DuZRu2LTMAETMAETKCeBHaAcGQVhl4lATAdcBOwVBXAeAwmYAImYAImkDOBm4GlIbySc7sDNVchAdBZBVgFGNmRiIEI+iYTMAETMAETyEZgVQhXZLu0+KsqJgA6IuBkYPPiXXcPJmACJmACJlAagVMgbFFabxk6qqIAmB+4FZg9w/h9iQmYgAmYgAlUncCTwBIQHqzSQCsoADqrADsBh1UJlMdiAiZgAiZgAgMS2BnC4QPeW9htVRUACgi8IQ6WsJmACZiACZhAbQkouH3ZqgT+jadYUQHQWQVYDriutlPugZuACZiACZgALA/h+iqCqLAA6IgALZnsWEVwHpMJmIAJmIAJpBA4AoK2tCtpVRcAswG3AAtWkp4HZQImYAImYAKTE7gfWBLC01UFVHEB0FkFWBM4v6oAPS4TMAETMAETmITAWhAuqDKZGgiAjgj4EbBplUF6bCZgAiZgAibQJXAahM2qTqMuAuBNgFIozlN1oB6fCZiACZhAqwk8Eqe0D49WnUJNBEBnFUArAFoJsJmACZiACZhAVQlsBuG0qg5u/LhqJAA6IuBMYKM6gPUYTcAETMAEWkfgLAgb18XrugkAbQH8Hpi3LoA9ThMwARMwgVYQeBh4NwRtAdTCaiYAOqsAGwJn1YKuB2kCJmACJtAWAhtB+HGdnK2hAOiIgOOBreoE2mM1ARMwARNoLIETIGxdN+/qKgBUKVD5lReqG3CP1wRMwARMoFEE7o3r1gRV/KuV1VQAdFYBVgEurxVtD9YETMAETKBpBFaFcEUdnaqxAOiIgP2BveoI3mM2ARMwAROoPYGpEPauqxd1FwCvAa4GlqnrBHjcJmACJmACtSRwI/BeCP+s5eiBmguAzirAIoAm4o11nQSP2wRMwARMoFYEnopfPMPdtRr1hME2QAB0RMCWwIl1ngiP3QRMwARMoDYEtoTw/dqMtsdAGyIAOiLgGGDbuk+Ix28CJmACJlBpAsdC2K7SI8w4uCYJgFmAG4DFM/ruy0zABEzABEygHwJ3AMtCeLafm6p6bYMEQGcVQA9/iQCJAZsJmIAJmIAJ5EVAD309/CUCGmENEwAdETAFOKERs2MnTMAETMAEqkJgKwiNijVroADoiIBvAztU5VPjcZiACZiACdSawHcgfLHWHkwy+KYKgJmAK4H3NG3C7I8JmIAJmECpBHTM/H0QXiy11xI6a6gA6KwCvAW41qWDS/gUuQsTMAETaCYBlfhdAcJ9TXSvwQKgIwJWBS5tRsKjJn787JMJmIAJVJZABKwGobE1ZxouADoiYBfgkMp+xDwwEzABEzCBKhLYFcKhVRxYXmNqgQDoiIBjgW3yguZ2TMAETMAEGk3gOAiNTyzXFgEwc7d08LKN/sjaORMwARMwgWEJKJeMSvy+MGxDVb+/JQKgswowP3ANsGDVJ8XjMwETMAETGAmB+4EVITw4kt5L7rRFAqAjApboioDXl8zZ3ZmACZiACVSbwHPdh/+t1R5mfqNrmQDoiIBPAqflh9AtmYAJmIAJNIDAphBOb4AfmV1ooQDoiIDdgQMzU/KFJmACJmACTSawB4SDmuzgZL61VAB0RIDTBbft025/TcAETGBaAo1M85tlotssAKYDzgXWzALK15iACZiACTSOwAXAuhBebpxnGRxqsQDorALMCvwWWDIDK19iAiZgAibQHAK3AKtAeLo5LvXnScsFQEcEzNctHLRwf+h8tQmYgAmYQE0J3AOsDOGhmo4/l2FbAHQwRot2VwLmzYWqGzEBEzABE6gqARX4UXW/u6o6wLLGZQHwb9LRUt1sgbOVBd/9mIAJmIAJlEpAy/3K8ndzqb1WtDMLgFdNTLQGcD4wU0Xny8MyARMwARMYjMCLwFoQLh7s9ubdZQEwzZx2EgX9yCWEm/dht0cmYAKtJaDSvpu1LdFP2mxbAExKKNoOODoNnv/dBEzABEygFgS2h3BMLUZa4iAtAHrCjnYGGl0LusTPmbsyARMwgVER2AXCYaPqvMr9WgAkzk60F7B/lSfQYzMBEzABE+hJYG8IU81ncgIWAKmfjGg/YN/Uy3yBCZiACZhAlQh8DYK+v209CFgAZPpoRN8A9s50qS8yARMwARMYNYH9Iewz6kFUvX8LgMwzFGkZac/Ml/tCEzABEzCBURA4AIK2b20pBCwA+vqIWAT0hcsXm4AJmEC5BPzw74O3BUAfsOJLvR3QNzLfYAImYALFE/Cyf5+MLQD6BNYVAQ4MHIibbzIBEzCBQgg44G8ArBYAA0DrigAfERyYnW80ARMwgdwI+KjfgCgtAAYE1xUBThY0FD/fbAImYAJDEXCSnyHwWQAMAa8rApQ2+CjXDhgapBswARMwgawElNv/c07vmxXX5NdZAAzHr3t3p4DQSa4imAtMN2ICJmACSQRU1W9LF/YZ/kNiATA8wzERoFLCPwFmy61JN2QCJmACJjCewNPABi7pm8+HwgIgH45jImAp4CJg3lybdWMmYAImYAIPAx+BcLNR5EPAAiAfjuNaiRYFfgUsnHvTbtAETMAE2kngHuBDEO5qp/vFeG0BUAjXaL7uSsCShTTvRk3ABEygPQRu6b75P9Qel8vx1AKgMM6RYgFOBdYsrAs3bAImYALNJnABsBmEZ5rt5mi8swAolHs0PXA4sEOh3bhxEzABE2gege8AO0J4pXmuVcMjC4BS5iHaHTiwlK7ciQmYgAnUn8AeEA6qvxvV9sACoLT56eQKOB54fWlduiMTMAETqBeB54Ctfca/nEmzACiHc7eXaAngQmDBUrt1ZyZgAiZQfQL3Ax+HcGv1h9qMEVoAlD6P0fzAOcCypXftDk3ABEygmgRuANaF8GA1h9fMUVkAjGReo5mBI4BtRtK9OzUBEzCB6hA4rhvs90J1htSOkVgAjHSeo12Ab7qQ0EgnwZ2bgAmMhoAK+nwZwqGj6d69WgCM/DMQrQqc4fTBI58ID8AETKA8AkrruwmEy8vr0j1NJGABUInPRPQW4GxgmUoMx4MwARMwgeII/A5YD8J9xXXhlrMQsADIQqmUa6KZgIOdNKgU2O7EBExgNASU3Gc3CCrpaxsxAQuAEU/AtN1HU7oBgrNUbmgekAmYgAkMRuDZbqDfiYPd7ruKIGABUATVoduMFgfOA/TbZgImYAJ1JnAHsDYE/bZViIAFQIUm49VDibQCoBMC21Z2iB6YCZiACSQTOLYb6a8VAFvFCFgAVGxCph1O9NluQaE3Vn6oHqAJmIAJxASeAnaGcJKBVJeABUB152bcyKJFgDN9SqAWk+VBmkDbCdwIbAzh7raDqLr/FgBVn6F/jy96DbAfsFdthuyBmoAJtI3A1Ph7KvyzbY7X0V8LgNrNWrQKcDKwUO2G7gGbgAk0lcC9wBYQrmiqg030ywKglrMazd4NENyqlsP3oE3ABJpE4IRuoN+TTXKqDb5YANR6lqMNASXWmLfWbnjwJmACdSSgdL47QPhxHQfvMYMFQO0/BdE8XRGwUe1dsQMmYAJ1IXBW9+H/SF0G7HFOS8ACoDGfimjT7nFBCQKbCZiACRRBQA/8nSCcVkTjbrNcAhYA5fIuuLfoTd00whIDNhMwARPIk4Ae+jtCeDTPRt3W6AhYAIyOfYE9R2sCRwMLFtiJmzYBE2gHgfuB7SFc0A532+OlBUBj5zqarZs3YMfGumjHTMAEiiZwRPdc/9NFd+T2yydgAVA+85J7jJYDlI976ZI7dncmYAL1JXBTXIckXF9fFzzyNAIWAGmEGvHv0XTAl4CvAMohYDMBEzCByQjoLP//At+C8IoRNZuABUCz53eCd9H8wEHA5q1y286agAlkIXAKsDuEB7Nc7GvqT8ACoP5zOIAHnXTCRwJLDXCzbzEBE2gWgZuBLziNb7MmNYs3FgBZKDXyms62wOeArwJzN9JFO2UCJpBE4DHg68BRXu5v5wfFAqCd8z7O62jOboXBLwAzth6HAZhA8wm81F0BnArhiea7aw97EbAA8GejSyBaDDgUWMdITMAEGkvgXGAXCHc21kM7lpmABUBmVG25MFq1W2lw+bZ4bD9NoAUErgV2g3B5C3y1ixkJWABkBNW+y6L1gQOAxdvnuz02gcYQuAPYE8LZjfHIjuRGwAIgN5RNbCiaAdga2AdYoIke2icTaCiBB4BvAMdD+FdDfbRbQxKwABgSYDtuj2aOc4FrCRFXG2zHpNvLehJQtb6D41og4YV6uuBRl0XAAqAs0o3oJ5qle3RwZ0CVB20mYALVIKAKfYd1j/Q9W40heRRVJ2ABUPUZquT4olm7KwIWApWcHw+qRQTGHvx643+mRX7b1RwIWADkALG9TURvALaJjxWhNMM2EzCBcggoXa+O7R4H4e/ldOlemkbAAqBpMzoSf6KZgM8AuwLKJ2AzARMohoDO7x8C/ADCi8V04VbbQsACoC0zXYqfkT5POj6oYEHnESiFuTtpCQGV5VVw308gRC3x2W4WTMACoGDA7W0+Wq27NbBWexnYcxMYmsD58VJ/uHToltyACUwgYAHgj0TBBKK3AwoW3BTQKQKbCZhAMgFF8Z8WR/WHPxmWCRRFwAKgKLJudwKBaHZgSvf0wKLGYwImMA2Bu+NjfJwI4UnzMYGiCVgAFE3Y7U9CIPpYXH+cjxuPCZgAF8bV+cLPzcIEyiRgAVAmbfc1cVXgrcD/dFcG5jUeE2gRgYfjN32+B+EvLfLbrlaIgAVAhSajvUPp1BxYsysGPgpM314W9rzBBF4GfhE/9LnAOfobPNM1cc0CoCYT1Z5hRkoo9Onuzzvb47c9bTCB24Afds/uP9RgP+1azQhYANRswto13GgFYAtgE2Cudvlub2tO4HHgDOBkCNfW3BcPv6EELAAaOrHNciuaEfgwsHl3q0ApiG0mUDUCSsmrc/unAr+E8FLVBujxmMB4AhYA/jzUjECn/oBOD3wS+Ajwupo54OE2i8DzwEXA6aBofuflb9b0NtsbC4Bmz2/DveuUJ9aRwo26YsCJhho+4xVxT4l69NA/C/g5BJffrcjEeBj9EbAA6I+Xr64sgWhm4IPAet0VgnkqO1QPrI4EHonf8Pkp8GsIL9TRCY/ZBLwF4M9Awwl0ihKtCKgOgVYIlm64w3avGAI3xW/4nX39a1yEpxjIbnV0BLwCMDr27rk0AtEC3SBCiQGtEigtsc0EJhJQ+t1fdx/6CuJ7wIhMoMkELACaPLv2bRIC0XTAsl0hsAbwXkDbB7b2EdAy/tXAxd0H/w0QXmkfBnvcVgIWAG2defvdJdCJHdB2wfu7P8v7ZEFjPxyK2L8OuAxQed1rvZff2Lm2YxkIWABkgORL2kQgei2wDLBy9+d9wJxtItAgX58ArgCuAq4EboTwjwb5Z1dMYCgCFgBD4fPN7SAQLdLdKtDWwXLAu4HXt8P32nj5HPB74HrghnhpP6i8rs0ETKAHAQsAfzRMoG8CkYoVvQN4T/eEwX93//uNfTflGwYh8BTwO+D/AEXq679vh6BiOzYTMIGMBCwAMoLyZSaQTqBz2uBd3Z8lABUzklDwqYN0eJNdoaj82wEV07kV+GP829H5g+H0XSbwagIWAP5EmEDhBCIlJVoceBuwWPdnYUA/bY8v0D79XwAt19/Z/fkzcAcEJd+xmYAJFETAAqAgsG7WBLIRiGYFFgLe0v2tVQSVRB77mbcrEur2txoBerg/DDw47kdn6+8F7ot/h2eycfJVJmACeROo25dK3v67PROoAYFohm455Lm7v7VqMEd3a0FxB7MBEhKqhaBiSQpQVJEkHXGcCdDJBlVU1HVZ7GlAlewUMf8ioPPyOkKnQDtVvFPuez24dZ3247VU/7fuA19lcB8DHofwryyd+RoTMIHREPh/gL37HtD3XfUAAAAASUVORK5CYII=",
              width: 60,
              alignment: "right",
              margin: [0, 0, 0, 0], // No bottom margin
              absolutePosition: { x: 500, y: 20 }, // Adjust x and y to fit your needs
            },
          ],
          margin: [0, 20, 0, 10],
        },
        {
          columns: [
            {
              width: "50%",
              stack: [
                {
                  text: `Bill To:\n\nName: ${name || "N/A"}\nEmail: ${
                    email || "N/A"
                  }\nID: ${id || "N/A"}\nCreated At: ${
                    createdAt ? moment(createdAt).format("DD-MM-YYYY") : "N/A"
                  }\n\nAddress: Doon Valley 12, Kitchener \nContact: +1123456789`,
                  style: "billingInfo",
                },
              ],
              margin: [0, 0, 20, 0],
            },
            {
              width: "50%",
              text: "Invoice Summary",
              style: "header",
              alignment: "right",
              margin: [0, 0, 0, 20],
              color: "#000080", // Dark red color for header
            },
          ],
        },
        ...createTableBody(appointments),
        {
          table: {
            widths: ["*", "auto"],
            body: [
              [
                { text: "Subtotal:", style: "summaryLabel" },
                { text: formatCurrency(subtotal), style: "summaryValue" },
              ],
              [
                { text: "Tax (13%):", style: "summaryLabel" },
                { text: formatCurrency(tax), style: "summaryValue" },
              ],
              [
                { text: "Grand Total:", style: "summaryLabel" },
                { text: formatCurrency(grandTotal), style: "summaryValue" },
              ],
            ],
          },
          layout: "noBorders",
          margin: [0, 10, 0, 0],
        },
        {
          text: "Terms and Conditions",
          style: "termsTitle",
          margin: [0, 40, 0, 10], // Increased top margin to move it lower
          color: "#000080", // Navy blue color for terms title
        },
        {
          text: `Click here for full Terms and Conditions`,
          style: "termsContent",
          margin: [0, 0, 0, 20],
          link: "https://poojanpradhan.com.np", // Replace with your actual URL
          color: "#000080", // Navy blue color
        },
        {
          stack: [
            {
              text: "Signature:",
              style: "signatureLabel",
              margin: [0, 20, 0, 10],
            },
            {
              text: "____________________",
              style: "signatureLine",
            },
          ],
          alignment: "left",
        },
      ],
      styles: {
        title: {
          fontSize: 18,
          bold: true,
          color: "#000080", // Dark red color for title
        },
        header: {
          fontSize: 16,
          bold: true,
          color: "#000080", // Dark red color for header
          margin: [0, 0, 0, 20],
        },
        billingInfo: {
          fontSize: 12,
          margin: [0, 0, 0, 10],
          bold: true,
          color: "#333", // Dark grey color for billing info
        },
        termsTitle: {
          fontSize: 14,
          bold: true,
          color: "#000080", // Dark red color for terms title
        },
        termsContent: {
          fontSize: 12,
          color: "#333", // Dark grey color for terms content
        },
        signatureLabel: {
          fontSize: 12,
          bold: true,
          color: "#333", // Dark grey color for signature label
        },
        signatureLine: {
          fontSize: 12,
          color: "#333", // Dark grey color for signature line
        },
        tableHeader: {
          fillColor: "#000080", // Dark red color for table headers
          bold: true,
          fontSize: 12,
          color: "#fff", // White color for table header text
          alignment: "center",
        },
        summaryLabel: {
          fontSize: 12,
          bold: true,
          color: "#333", // Dark grey color for summary labels
        },
        summaryValue: {
          fontSize: 12,
          color: "#333", // Dark grey color for summary values
          alignment: "right",
        },
      },
      defaultStyle: {
        fontSize: 10,
      },
    };

    pdfMake.createPdf(docDefinition).download("appointments.pdf");
  };

  return (
    <Layout>
      <h1>Appointment Lists</h1>
      <Button type="primary" onClick={generatePDF}>
        Download PDF
      </Button>
      <Table
        columns={columns}
        dataSource={appointments}
        rowKey="id"
        pagination={false} // Disable pagination if you want to handle it manually or add pagination controls
        bordered
        size="middle"
        scroll={{ x: true }} // Enable horizontal scrolling if needed
        style={{ margin: "20px 0" }} // Optional: add margin around the table
      />
    </Layout>
  );
};

export default Appointments;
