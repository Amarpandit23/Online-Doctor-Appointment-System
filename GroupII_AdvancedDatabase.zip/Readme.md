GROUP PROJECT - ADVANCED JAVASCRIPT

ODAS - Online Doctor Appointment System.

Fullstack NodeJS & React Application with MYSQL and PDFMake to generate reports.

SECTION 6 - GROUP II

GROUP MEMBERS:

1 - Poojan Pradhan (8958434)
2 - Amar Pandit (8964045)
3 - Nikhilesh Raut (8998293)

GROUP CONTRIBUTIONS:

Poojan - Took charge of overseeing the entire project from start to completion, contributed to both frontend and backend development, and managed database table integration.

Nikhilesh - Assisted with custom component styling and researched similar projects for reference. Played a key role in table development and implementing third normal form (3NF) principles.

Amar Pandit - Contributed to designing the ER Diagram and worked on ReactJS components.

HOW TO START:

Create .env from sample and use your credentials.

NOTE: We are utilizing Sequlize ORM to handle Database Sync and Integration on NodeJS, so if you want to use your own migrations and create/insert queries, config -> db.js -> comment out sync db, else, sequelize automatically creates tables and relations.

1. npm i
2. cd client
3. npm i

4. npm start

5. cd client && npm start.

(Optional - Run concurrently)

- npm run dev

APPLICATION FEATURES:

- User Authentication (Sign up and Login)

- Apply for Doctor.

- Admin Approval

- Doctor List

- Book Appointment

- Appointment List

- Notifications.

- Generate PDF.

ADDITIONAL FILES:

1. ER Diagram.
2. DB SQL FILE for create tables and INSERT Queries(3NF)
