-- GROUP II - SECTION VI WEB DEVELOPMENT (Poojan,Nikhilesh,Amar) - Online Doctor Appointment System.

-- FOUR TABLES: USERS, DOCTORS, APPOINTMENTS & NOTIFICATIONS. 

DROP DATABASE IF EXISTS odas_db;
CREATE DATABASE odas_db;
USE odas_db;

-- users table creation 
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    isAdmin BOOLEAN DEFAULT FALSE,
    isDoctor BOOLEAN DEFAULT FALSE,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- doctors table creation 
CREATE TABLE doctors (
    id INTEGER PRIMARY KEY,
    userId INTEGER NOT NULL UNIQUE,
    firstName VARCHAR(255) NOT NULL,
    lastName VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    website VARCHAR(255),
    address TEXT NOT NULL,
    specialization VARCHAR(255) NOT NULL,
    experience TEXT NOT NULL,
    feesPerConsultation DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    timings JSON NOT NULL,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(id)
);

-- appointments table creation 
CREATE TABLE appointments (
    id INTEGER PRIMARY KEY,
    userId INTEGER NOT NULL,
    doctorId INTEGER NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    status ENUM('pending', 'confirmed', 'canceled') DEFAULT 'pending',
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(id),
    FOREIGN KEY (doctorId) REFERENCES doctors(id)
);

-- notifications table creation 
CREATE TABLE notifications (
    id INTEGER PRIMARY KEY,
    userId INTEGER NOT NULL,
    type VARCHAR(255) NOT NULL,
    message VARCHAR(255) NOT NULL,
    seen BOOLEAN DEFAULT FALSE,
    onClickPath VARCHAR(255),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(id)
);


-- INSERT QUERIES
INSERT INTO users (id, name, email, password, isAdmin, isDoctor, createdAt, updatedAt) VALUES
(1,'John Doe', 'john.doe@example.com', 'password123', false, true, NOW(), NOW()),
(2,'Jane Smith', 'jane.smith@example.com', 'password123', false, false, NOW(), NOW()),
(3,'Alice Johnson', 'alice.johnson@example.com', 'password123', false, true, NOW(), NOW()),
(4,'Bob Brown', 'bob.brown@example.com', 'password123', false, false, NOW(), NOW()),
(5,'Charlie Davis', 'charlie.davis@example.com', 'password123', true, true, NOW(), NOW()),
(6,'David Miller', 'david.miller@example.com', 'password123', false, false, NOW(), NOW()),
(7,'Eve Wilson', 'eve.wilson@example.com', 'password123', false, true, NOW(), NOW()),
(8,'Frank Thomas', 'frank.thomas@example.com', 'password123', false, false, NOW(), NOW()),
(9,'Grace Lee', 'grace.lee@example.com', 'password123', false, true, NOW(), NOW()),
(10,'Hank Moore', 'hank.moore@example.com', 'password123', false, false, NOW(), NOW());

INSERT INTO doctors (id,userId, firstName, lastName, phone, email, website, address, specialization, experience, feesPerConsultation, status, timings, createdAt, updatedAt) VALUES
(1,1, 'John', 'Doe', '555-1234', 'john.doe@doctor.com', 'www.johndoe.com', '123 Main St', 'Cardiology', '10 years of experience', 200.00, 'approved', '{"monday": ["09:00", "17:00"], "tuesday": ["09:00", "17:00"]}', NOW(), NOW()),
(2,3, 'Alice', 'Johnson', '555-2345', 'alice.johnson@doctor.com', NULL, '456 Elm St', 'Dermatology', '8 years of experience', 180.00, 'approved', '{"wednesday": ["10:00", "16:00"], "thursday": ["10:00", "16:00"]}', NOW(), NOW()),
(3,5, 'Charlie', 'Davis', '555-3456', 'charlie.davis@doctor.com', 'www.charliedavis.com', '789 Oak St', 'Pediatrics', '12 years of experience', 220.00, 'approved', '{"friday": ["11:00", "15:00"], "saturday": ["11:00", "15:00"]}', NOW(), NOW()),
(4,7, 'Eve', 'Wilson', '555-4567', 'eve.wilson@doctor.com', 'www.evewilson.com', '101 Maple St', 'Orthopedics', '15 years of experience', 250.00, 'approved', '{"monday": ["13:00", "18:00"], "wednesday": ["13:00", "18:00"]}', NOW(), NOW()),
(5,9, 'Grace', 'Lee', '555-5678', 'grace.lee@doctor.com', 'www.gracelee.com', '202 Pine St', 'Neurology', '20 years of experience', 300.00, 'approved', '{"tuesday": ["14:00", "19:00"], "thursday": ["14:00", "19:00"]}', NOW(), NOW());


INSERT INTO appointments (id, userId, doctorId, date, time, status, createdAt, updatedAt) VALUES
(4, 2, 1, '2024-08-16', '09:00:00', 'confirmed', NOW(), NOW()),
(3, 4, 3, '2024-08-17', '10:00:00', 'pending', NOW(), NOW()),
(2, 6, 5, '2024-08-18', '11:00:00', 'canceled', NOW(), NOW()),
(1, 8, 7, '2024-08-19', '12:00:00', 'confirmed', NOW(), NOW()),
(5, 10, 9, '2024-08-20', '13:00:00', 'pending', NOW(), NOW());

INSERT INTO notifications (id, userId, type, message, seen, onClickPath, createdAt, updatedAt) VALUES
(1, 2, 'appointment', 'Your appointment has been confirmed.', false, '/appointments/1', NOW(), NOW()),
(9, 4, 'appointment', 'Your appointment is pending.', false, '/appointments/2', NOW(), NOW()),
(10, 6, 'appointment', 'Your appointment has been canceled.', true, '/appointments/3', NOW(), NOW()),
(12, 8, 'appointment', 'Your appointment has been confirmed.', false, '/appointments/4', NOW(), NOW()),
(15, 10, 'appointment', 'Your appointment is pending.', false, '/appointments/5', NOW(), NOW()),
(2, 2, 'reminder', 'Don\'t forget your appointment tomorrow.', true, '/appointments/6', NOW(), NOW()),
(11, 4, 'reminder', 'Don\'t forget your appointment tomorrow.', false, '/appointments/7', NOW(), NOW()),
(52, 5, 'reminder', 'Don\'t forget your appointment tomorrow.', true, '/appointments/8', NOW(), NOW()),
(50, 1, 'reminder', 'Don\'t forget your appointment tomorrow.', false, '/appointments/9', NOW(), NOW()),
(29, 3, 'reminder', 'Don\'t forget your appointment tomorrow.', false, '/appointments/10', NOW(), NOW()); 